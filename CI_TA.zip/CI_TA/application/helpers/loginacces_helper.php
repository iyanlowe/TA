<?php

function login_in_admin ()
{
	$ci = get_instance(); 
	if (!$ci->session->userdata('email')) {
		redirect('auth');
	}else{
		if ($ci->session->userdata('role_id') == 2) {
			redirect('penguji/penguji/blocked');
		}
	}
}

function login_in_penguji ()
{
	$ci = get_instance(); 
	if (!$ci->session->userdata('email')) {
		redirect('auth');
	}else{
		if ($ci->session->userdata('role_id') == 1) {
			redirect('admin/blocked');
		}
	}
}