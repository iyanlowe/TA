<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_typedevice extends CI_Model {

	public function getAllTypeDevice() {
		return $this->db->get('typedevice')->result_array();
	}

	public function tambahTypeDevice() {
		$data = [
			'nama_typedevice' => $this->input->post('nama_type'),
			'ket_typedevice' => $this->input->post('ket_type'),
		];
		$this->db->insert('typedevice', $data);
	}

	public function hapusTypeDevice($id_typedevice) {
		$this->db->where('id_typedevice', $id_typedevice);
		$this->db->delete('typedevice');
	}

	public function getDataTypeDevice($id_typedevice) {
		return $this->db->get_where('typedevice', ['id_typedevice' => $id_typedevice])->row_array();
	}
	
	public function ubahTypeDevice($data)
	{
		$data = [
			'nama_typedevice' => $this->input->post('nama_type'),
			'ket_typedevice' => $this->input->post('ket_type'),
		];
		$this->db->where('id_typedevice', $this->input->post('id_typedevice'));
		$this->db->update('typedevice', $data);
	}
}


