<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_admin extends CI_Model

{
	public function listing()
	{
		return $this->db->get('user')->num_rows();
	}
}