<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use Ozdemir\Datatables\Datatables;
use Ozdemir\Datatables\DB\CodeigniterAdapter;

class Modelkategori_produk extends CI_Model {
	protected $dataTable;

	public function __construct()
	{
		$this->dataTable = new Datatables(new CodeigniterAdapter);
	}

	public function getAllProduk() {
		$this->db->join('kategori', 'kategori.id_kategori = data_produk.id_kategori');
		return $this->db->get('data_produk')->result();

	}

	public function getAllProduks() {
		$this->db->join('kategori', 'kategori.id_kategori = data_produk.id_kategori');
		return $this->db->get('data_produk')->result_array();

	}

	public function tambahKategori() {
		$data = [
			'nama_kategori' => $this->input->post('nama_kategori'),
			'keterangan' => $this->input->post('keterangan'),
		];
		$this->db->insert('kategori', $data);
	}

	public function hapusDataKategori($id_kategori) {
		$this->db->where('id_kategori', $id_kategori);
		$this->db->delete('kategori');
	}

	public function getDataProdukById($id_kategori) {

		return $this->db->get_where('kategori', ['id_kategori' => $id_kategori])->row_array();
	}

	public function getAllDataKategoriAjax() {
		return $this->db->get('kategori')->result_array();
	}

	public function listKategori() {

		return $this->db->get('kategori')->result_array();
	}

	public function ubahDataKategori() {
		$data = [
			'nama_kategori' => $this->input->post('nama_kategori'),
			'keterangan' => $this->input->post('keterangan'),
		];
		$this->db->where('id_kategori', $this->input->post('id_kategori'));
		$this->db->update('kategori', $data);
	}

	public function read()
	{
		
		$this->dataTable->query('
			SELECT
			NULL AS no,
			Null AS view,
			nama_kategori,
			keterangan,
			NULL AS action,
			id_kategori 
			FROM kategori
			-- JOIN kategori ON kategori.id_kategori = data_produk.id_kategori
			ORDER BY id_kategori ASC
			');


		$this->dataTable->edit('view', function ($data) {
			return '<center><a href="#" class="tampilModalKat" data-id_kategori="'.$data['id_kategori'].'"><i class="fa fa-folder-open"></i></a></center>';
		});
		$this->dataTable->edit('action', function ($data) {
			return '<center><a href="#" class="btn btn-warning btn-xs UbahKategori" data-id_kategori="'.$data['id_kategori'].'"><i class="fa fa-edit"></i>edit</a>' . ' <a href="hapuskategori/'.$data['id_kategori'].'" class = "btn btn-danger btn-xs tombolHapusKat"><i class="fa fa-trash-o"></i>delete</a></center>';
		});

		return $this->dataTable->generate();
	}

	  

}

