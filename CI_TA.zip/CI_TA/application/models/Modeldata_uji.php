<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Modeldata_uji extends CI_Model {
	public function getAllUjiData() {
		$this->db->join('kategori', 'data_uji.id_kategori=kategori.id_kategori');
		return $this->db->get('data_uji')->result_array();
	}

	public function tambahDataUji() {
		$data = [
			'nama_datauji' => $this->input->post('nama_datauji'),
			'id_kategori' => $this->input->post('id_kate'),
		];
		$this->db->insert('data_uji', $data);
	}

	public function hapusDataUji($id_ujidata) {
		$this->db->where('id_ujidata', $id_ujidata);
		$this->db->delete('data_uji');
	}

	public function getDataUjiById($id_ujidata) {
		$this->db->join('kategori', 'data_uji.id_kategori=kategori.id_kategori');
		return $this->db->get_where('data_uji', ['id_ujidata' => $id_ujidata])->row_array();
	}
	public function ubahDataUji($data) {
		$data = [
			'nama_datauji' => $this->input->post('nama_datauji'),
			'id_kategori' => $this->input->post('id_kate'),
		];
		$this->db->where('id_ujidata', $this->input->post('id_ujidata'));
		$this->db->update('data_uji', $data);
	}

}