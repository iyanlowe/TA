<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Bencana_model extends CI_Model {

	//fungsi join 
	public function listing()
	{
		$this->db->select('bencana.*,
						   jenis_bencana.jenis_bencana');
		$this->db->from('bencana');
		//JOIN
		$this->db->join('jenis_bencana', 'jenis_bencana.id_jenis_bencana = bencana.id_jenis_bencana', 'left');
		//End Join
		$this->db->group_by('bencana.id_bencana');
		$this->db->order_by('id_bencana','desc');
		$query = $this->db->get();
		return $query->result_array();
	}
	//fungsi jenis bencana
	public function Jenislisting() {
		return $this->db->get('jenis_bencana')->result_array();
	}
	public function hapusJenisBencana($id_jenis_bencana) {
		$this->db->where('id_jenis_bencana', $id_jenis_bencana);
		$this->db->delete('jenis_bencana');
	}
	public function JenislistingbyId($id_jenis_bencana) {
		return $this->db->get_where('jenis_bencana', ['id_jenis_bencana'=>$id_jenis_bencana])->row_array();
	}
	public 	function addJenis($data)
	{
		$this->db->insert('jenis_bencana', $data);
	}

	public function editJenis($where,$data)
	{
		$this->db->where($where);
		$this->db->update('jenis_bencana',$data);
	}

	
	//fungsi bencana
	public 	function addBencana($data)
	{
		$this->db->insert('bencana', $data);
	}
	public function BencanalistingbyId($id_bencana) {
		return $this->db->get_where('bencana', ['id_bencana'=> $id_bencana])->row_array();
	}
	public function editBencana($where,$data)
	{
		$this->db->where($where);
		$this->db->update('bencana',$data);
	}
	public function hapusBencana($id_bencana) {
		$this->db->where('id_bencana', $id_bencana);
		$this->db->delete('bencana');
	}

}

/* End of file User_bencana.php */
/* Location: ./application/models/User_bencana.php */