<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {

public function listing() {
	$this->db->select('user.*,
						user_role.jabatan');
		$this->db->from('user');
		//Join
		$this->db->join('user_role', 'user_role.role_id = user.role_id', 'left');
		//End Join
		$this->db->where('active_id','1');
		$this->db->group_by('user.id_user');
		$this->db->order_by('id_user','asc');
		$query = $this->db->get();
		return $query->result();
	}

// Detail petugas
	public function detail($id_user) 
	{

		$this->db->select('*');
		$this->db->from('user');
		$this->db->where('id_user',$id_user);
		$this->db->order_by('id_user','desc');
		$query = $this->db->get();
		return $query->row();
	}


    public function ubahProfile()
	{
		$data = [
			'fname' => $this->input->post('fname'),
			'lname' => $this->input->post('lname'),
			'jenis_kelamin' => $this->input->post('jenis_kelamin'),
			'tanggal_lahir' => $this->input->post('tanggal_lahir'),
			'tempat_lahir' => $this->input->post('tempat_lahir'),
		];
		$this->db->where('id', $this->input->post('id_profil'));
		$this->db->update('user', $data);
	}
	 public function ubahPassword()
	{
		$data = [
			'fname' => $this->input->post('fname'),
			'lname' => $this->input->post('lname'),
			'jenis_kelamin' => $this->input->post('jenis_kelamin'),
			'tanggal_lahir' => $this->input->post('tanggal_lahir'),
			'tempat_lahir' => $this->input->post('tempat_lahir'),
		];
		$this->db->where('id', $this->input->post('id_profil'));
		$this->db->update('user', $data);
	}
	
	public function listingPetugasA() {
	$this->db->select('user.*,
						user_role.role_id');
		$this->db->from('user');
		//Join
		$this->db->join('user_role', 'user_role.role_id = user.role_id', 'left');
		//End Join
		
		$this->db->where('role_id','2');
		$this->db->order_by('id','asc');
		$query = $this->db->get();
		return $query->result();
	}



}

/* End of file User_model.php */
/* Location: ./application/models/User_model.php */