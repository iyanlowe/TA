<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Modelmanag_data extends CI_Model

{
	public function getAllData()
	{
		$data = [
			'kode_produk' => $this->input->post('kode_produk'),
			'nama_produk' => $this->input->post('nama_produk'),
			'id_kategori' => $this->input->post('id_kat'),
			'keterangan_produk' => $this->input->post('keterangan_produk'),
		];
		$this->db->insert('data_produk', $data);
	}

	public function hapusDataProduk($id_produk)
	{
		$this->db->where('id_produk', $id_produk);
		$this->db->delete('data_produk');
	}

	public function getDataProdukById($id_produk)
	{
		$this->db->join('kategori','kategori.id_kategori = data_produk.id_kategori');
		return $this->db->get_where('data_produk', ['id_produk' => $id_produk])->row_array(); 
	}

	public function ubahDataProduk()
	{
		$data = [
			'kode_produk' => $this->input->post('kode_produk'),
			'nama_produk' => $this->input->post('nama_produk'),
			'id_kategori' => $this->input->post('id_kat'),
			'keterangan_produk' => $this->input->post('keterangan_produk'),
		];
		$this->db->where('id_produk', $this->input->post('id_produk'));
		$this->db->update('data_produk', $data);
	}

	public function getDataUsersById($id_pelanggan)
	{
		
		return $this->db->get_where('pelanggan', ['id_pelanggan' => $id_pelanggan])->row_array(); 
	}

}

