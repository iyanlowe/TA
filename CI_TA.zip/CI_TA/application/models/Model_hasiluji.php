<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_hasiluji extends CI_Model

{
	public function getAllDataDevice()
	{

		$this->db->join('device', 'hasil_uji.id_device=device.id_device');
		$this->db->join('typedevice', 'typedevice.id_typedevice=device.id_typedevice');
		$this->db->join('pilih_hasil', 'pilih_hasil.id_hasilpilih=hasil_uji.id_hasilpilih');
		return $this->db->get('hasil_uji')->result();
	}

	public function getAllDataUjiById($id_hasiluji) {
		$this->db->join('data_uji', 'data_hasil_uji.id_ujidata=data_uji.id_ujidata');
		return $this->db->get_where('data_hasil_uji', ['id_hasiluji' => $id_hasiluji])->result();
	}
	public function getAll()
	{
		$this->db->join('device', 'hasil_uji.id_device=device.id_device');
		$this->db->join('typedevice', 'typedevice.id_typedevice=device.id_typedevice');
		$this->db->join('pilih_hasil', 'pilih_hasil.id_hasilpilih=hasil_uji.id_hasilpilih');
		return $this->db->get('hasil_uji')->result(); 

	}

	public function total_rowsreport()
	{

		return $this->db->get('hasil_uji')->num_rows();
	}

	public function hapusHasilUji($id_hasiluji) {

		$this->db->delete('hasil_uji', ['id_hasiluji' => $id_hasiluji]);
		$this->db->delete('data_hasil_uji', ['id_hasiluji' => $id_hasiluji]);
	}

	

}