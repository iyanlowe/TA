<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kerusakan_model extends CI_Model {

	//fungsi join 
	public function listing()
	{
		$this->db->select('kerusakan.*,
						   jenis_kerusakan.id_jenis_kerusakan');
		$this->db->from('kerusakan');
		//JOIN
		$this->db->join('jenis_kerusakan', 'jenis_kerusakan.id_jenis_kerusakan = kerusakan.id_jenis_kerusakan', 'left');
		//End Join
		$this->db->group_by('kerusakan.id_kerusakan');
		$this->db->order_by('id_kerusakan','desc');
		$query = $this->db->get();
		return $query->result_array();
	}
	//fungsi jenis Kerusakan
	public function Jenislisting() {
		return $this->db->get('jenis_kerusakan')->result_array();
	}
	public function hapusJenisKerusakan($id_jenis_kerusakan) {
		$this->db->where('id_jenis_kerusakan', $id_jenis_kerusakan);
		$this->db->delete('jenis_kerusakan');
	}
	public function JenislistingbyId($id_jenis_kerusakan) {
		return $this->db->get_where('jenis_kerusakan', ['id_jenis_kerusakan'=>$id_jenis_kerusakan])->row_array();
	}
	public 	function addJenis($data)
	{
		$this->db->insert('jenis_kerusakan', $data);
	}

	public function editJenis($where,$data)
	{
		$this->db->where($where);
		$this->db->update('jenis_kerusakan',$data);
	}

	
	//fungsi bencana
	public 	function addKerusakan($data)
	{
		$this->db->insert('kerusakan', $data);
	}
	public function KerusakanlistingbyId($id_kerusakan) {
		return $this->db->get_where('kerusakan', ['id_kerusakan'=> $id_kerusakan])->row_array();
	}
	public function editKerusakan($where,$data)
	{
		$this->db->where($where);
		$this->db->update('kerusakan',$data);
	}
	public function hapusKerusakan($id_kerusakan) {
		$this->db->where('id_kerusakan', $id_kerusakan);
		$this->db->delete('kerusakan');
	}

}

/* End of file Kerusakan_model.php */
/* Location: ./application/models/Kerusakan_model.php */