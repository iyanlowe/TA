<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api_modeldatauji extends CI_Model
{
	public function getDatauji($id_ujidata = null)
	{
		if ($id_ujidata === null) {
			return $this->db->get('data_uji')->result_array();
		}else{
			return $this->db->get_where('data_uji', ['id_ujidata' => $id_ujidata])->result_array();
		}
		
	}

	public function deleteDatauji($id_ujidata)
	{
		$this->db->delete('data_uji', ['id_ujidata' => $id_ujidata]);
		return $this->db->affected_rows();
	}

	public function createDatauji($data)
	{
		$this->db->insert('data_uji', $data);
		return $this->db->affected_rows();
	}

	public function updateDatauji($data, $id_ujidata)
	{
		$this->db->update('data_uji', $data, ['id_ujidata' => $id_ujidata]);
		return $this->db->affected_rows();
	}
}
