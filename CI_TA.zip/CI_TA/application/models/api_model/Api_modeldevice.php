<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api_modeldevice extends CI_Model
{
	public function getDevice($id_typedevice = null)
	{
		if ($id_typedevice === null) {
			return $this->db->get('typedevice')->result_array();
		}else{
			return $this->db->get_where('typedevice', ['id_typedevice' => $id_typedevice])->result_array();
		}
		
	}

	public function deleteDevice($id_typedevice)
	{
		$this->db->delete('typedevice', ['id_typedevice' => $id_typedevice]);
		return $this->db->affected_rows();
	}

	public function createDevice($data)
	{
		$this->db->insert('typedevice', $data);
		return $this->db->affected_rows();
	}

	public function updateDevice($data, $id_typedevice)
	{
		$this->db->update('typedevice', $data, ['id_typedevice' => $id_typedevice]);
		return $this->db->affected_rows();
	}
}
