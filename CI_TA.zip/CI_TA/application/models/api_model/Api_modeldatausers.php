<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api_modeldatausers extends CI_Model
{
	public function getUsers($id = null)
	{
		if ($id === null) {
			return $this->db->get('user')->result_array();
		}else{
			return $this->db->get_where('user', ['id' => $id])->result_array();
		}
		
	}

	public function checkUsers($con, $id_user)
	{
		$this->db->get_where('user', $con, ['id' => $id_user])->result_array();
		return $this->db->affected_rows();
	}

	public function createUsers($data)
	{
		$token = base64_encode(random_bytes(32));
		$email = $this->input->post('email', true);
		$user_token = [
			'email' => $email,
			'token' => $token,
			'date_created' => time()
		];
		$this->db->insert('user', $data);
		$this->db->insert('user_token', $user_token);

		$this-> _sendEmail($token, 'verify');
		return $this->db->affected_rows();
	}

	private function _sendEmail($token, $type)
	{
		$config['protocol']    = 'smtp';
		$config['smtp_host']    = 'ssl://smtp.googlemail.com';
		$config['smtp_port']    = '465';
		$config['smtp_timeout'] = '7';
		$config['smtp_user']    = 'qualitycontrolsystem00@gmail.com';
		$config['smtp_pass']    = '54111241Qc';
		$config['charset']    = 'utf-8';
		$config['newline']    = "\r\n";
		$config['mailtype'] = 'html'; 
		$config['validation'] = FALSE;

		$this->email->initialize($config);
		$this->email->from('qualitycontrolsystem00@gmail.com','Quality Control System');
		$this->email->to($this->input->post('email')); 

		if ($type == 'verify') {
			$this->email->subject('Account Verification');
			$this->email->message('Click this link to verify your account : <a href="'. base_url() . 'auth/verify?email=' . $this->input->post('email') . '&token=' . urlencode($token) . '">Active</a>'); 
		}elseif ($type == 'forgot') {
			$this->email->subject('Reset Password');
			$this->email->message('Click this link to reset your password : <a href="'. base_url() . 'auth/resetpassword ?email=' . $this->input->post('email') . '&token=' . urlencode($token) . '">Reset Password</a>');
		}

		$send = $this->email->send();
		if($send) {
			return true;
		} else {
			echo $this->email->print_debugger();

		}

	}

	public function verify()
	{
		$email = $this->input->get('email');
		$token = $this->input->get('token');

		$user = $this->db->get_where('user', ['email' => $email])->row_array();

		if ($user) {
			$user_token = $this->db->get_where('user_token', ['token' => $token])->row_array();

			if ($user_token) {
				if (time() - $user_token['date_created'] < (60*60*24)) {
					$this->db->set('active_id', 1);
					$this->db->where('email', $email);
					$this->db->update('user');
					$this->db->delete('user_token', ['email' => $email]);
				}else{
					$this->db->delete('user', ['email' => $email]);
					$this->db->delete('user_token', ['email' => $email]);
				}
			}else{
				$this->response([
						'status' => FALSE,
						'message' => 'Token anda tidak benar kawan'
					], REST_Controller::HTTP_NOT_FOUND);
			}

		}else {
			$this->response([
						'status' => FALSE,
						'message' => 'Email anda tidak benar kawan'
					], REST_Controller::HTTP_NOT_FOUND);
		}
	}

}




