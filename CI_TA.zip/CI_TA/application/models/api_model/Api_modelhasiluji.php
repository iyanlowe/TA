<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api_modelhasiluji extends CI_Model
{
	public function createHasilUji($data)
	{
		
		return $this->db->insert('data_hasil_uji', $data);
	}

	public function getHasilUji($id_hasiluji = null)
	{
		if ($id_hasiluji === null) {

			$this->db->join('device', 'device.id_device=hasil_uji.id_device');
			$this->db->join('typedevice', 'typedevice.id_typedevice=device.id_typedevice');
			return $this->db->get('hasil_uji')->result_array();
		}else{
			return $this->db->get_where('hasil_uji', ['id_hasiluji' => $id_hasiluji])->result_array();
		}
		
	}
}