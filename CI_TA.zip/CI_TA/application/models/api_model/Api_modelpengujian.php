<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api_modelpengujian extends CI_Model
{
	public function getPengujian($id_pengujian = null)
	{
		if ($id_pengujian === null) {
			
			return $this->db->get('pengujian')->result_array();
		}else{
			return $this->db->get_where('pengujian', ['id_pengujian' => $id_pengujian])->result_array();
		}
		
	}

	public function deletePengujian($id_pengujian)
	{
		$this->db->delete('pengujian', ['id_pengujian' => $id_pengujian]);
		return $this->db->affected_rows();
	}

	public function createPengujian($data)
	{
		$this->db->insert('pengujian', $data);
		return $this->db->affected_rows();
	}

	public function updatePengujian($data, $id_pengujian)
	{
		$this->db->update('pengujian', $data, ['id_pengujian' => $id_pengujian]);
		return $this->db->affected_rows();
	}
}
