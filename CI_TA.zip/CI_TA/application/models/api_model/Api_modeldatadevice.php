<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api_modeldatadevice extends CI_Model
{

	public function getDevice($id_device = null)
	{
		if ($id_device === null) {
			// $this->db->join('typedevice', 'typedevice.id_typedevice=device.id_typedevice');
			// $this->db->join('data_device', 'data_device.id_device=device.id_device');
			// $this->db->join('kategori', 'kategori.id_kategori=data_device.id_kategori');
			// $this->db->join('data_uji', 'data_uji.id_kategori=kategori.id_kategori');
			// return $this->db->get('device')->result();
			// $query = $this->db->query('SELECT kode_device FROM device LIMIT 1');
			// $row = $query->row();
			// echo $row->kode_device;

			// return $this->db->query('SELECT kode_device, id_typedevice FROM device');
			// return $this->db->get('device')->result();
			$this->db->select("kode_device");	
			$this->db->group_by("kode_device");
			$this->db->order_by("kode_device","asc");
			
			return $this->db->get('device')->result();

			// $this->db->select('kode_device,id_typedevice');
			// $this->db->from('device');
			// // $this->db->like('kode_device');

			// return $query = $this->db->get();
		}else{
			$this->db->join('typedevice', 'typedevice.id_typedevice=device.id_typedevice');
			// $this->db->join('data_device', 'data_device.id_device=device.id_device');
			// $this->db->join('kategori', 'kategori.id_kategori=data_device.id_kategori');
			// $this->db->join('data_uji', 'data_uji.id_kategori=kategori.id_kategori');
			return $this->db->get_where('device', ['id_device' => $id_device])->result();
		}
		
	}
	public function createDataDevice($data)
	{
		$this->db->insert('device', $data);
		return $this->db->affected_rows();
	}

	public function getDataDeviceById($id)
	{
		$this->db->select('device.kode_device,device.id_device,typedevice.nama_typedevice');
		$this->db->where('device.kode_device',$id);
		$this->db->join('typedevice', 'typedevice.id_typedevice=device.id_typedevice');
		return $this->db->get('device')->row();
	}

	public function getDeviceHasilUji($id){
		$this->db->select('pilih_hasil.nama_hasilpilih');
		$this->db->where('hasil_uji.id_device',$id);
		$this->db->join('pilih_hasil','pilih_hasil.id_hasilpilih=hasil_uji.id_hasilpilih');
		return $this->db->get('hasil_uji')->row();
	}
	public function getAllDataKategoriById($id) {
		$this->db->select('kategori.id_kategori,kategori.nama_kategori');
		$this->db->join('kategori', 'data_device.id_kategori=kategori.id_kategori');
		return $this->db->get_where('data_device', ['data_device.id_device' => $id])->result();
	}
	public function getAllDataUjiByCat($id) {
		return $this->db->get_where('data_uji', ['id_kategori' => $id])->result();
	}
}
