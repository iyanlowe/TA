<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_pengujian extends CI_Model

{


	public function getDatsP()
	{
		$this->db->join('typedevice', 'typedevice.id_typedevice = device.id_typedevice');
		return $this->db->get_where('device', ['kode_device' => $this->session->userdata('kode_device')])->row_array();
	}

	// public function getAllPengujian()
	// {
	// 	$this->db->join('data_produk','pengujian.id_produk=data_produk.id_produk');
	// 	$this->db->join('kategori','data_produk.id_kategori=kategori.id_kategori');
	// 	return $this->db->get('pengujian')->result();
	// }
	// public function getAllDataUji()
	// {

	// 	return $this->db->get('data_uji')->result();
	// }
	// public function getAllDataUjiById($id){
	// 	$this->db->join('data_uji','data_pengujian.id_ujidata=data_uji.id_ujidata');
	// 	return $this->db->get_where('data_pengujian', ['id_pengujian' => $id])->result();
	// }

	// 	public function getViewAllDataUjiById($id){
	// 	$this->db->join('data_uji','data_pengujian.id_ujidata=data_uji.id_ujidata');
	// 	return $this->db->get_where('data_pengujian', ['id_pengujian' => $id])->result();
	// }

	// 	public function hapusList($id_pengujian)
	// {
	// 	$this->db->where('id_pengujian', $id_pengujian);
	// 	$this->db->delete('pengujian');
	// }

}