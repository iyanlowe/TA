<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Modeldata_users extends CI_Model

{
	public function tambahUsers()
	{
		$data = [
			'nama_pelanggan' => $this->input->post('nama_pelanggan'),
			'email' => $this->input->post('email'),
			'password' => $this->input->post('password'),
			'telepon' => $this->input->post('telepon'),
			'alamat' => $this->input->post('alamat'),
		];
		$this->db->insert('pelanggan', $data);
	}

	public function hapusDataUsers($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('user');
	}

	public function getDataProdukById($id)
	{
		
		return $this->db->get_where('user', ['id' => $id])->row_array(); 
	}

}