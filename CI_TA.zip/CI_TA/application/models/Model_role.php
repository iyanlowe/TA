<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_role extends CI_Model {

public function listing() 
	{

		$this->db->select('*');
		$this->db->from('user_role');
		$this->db->order_by('role_id','desc');
		$query = $this->db->get();
		return $query->result();
	}

	// Listing all berdasarkan header
	public function jabatan($role_id) 
	{
		 $this->db->join('user','user.role_id=user_role.role_id');
		 return $this->db->get_where('user_role', ['user_role.role_id' => $role_id])->row_array();
		 
	}

	//Edit Kategori
	public function edit($data)
	{
		$this->db->where('id',$data['id']);
		$this->db->update('user',$data);
	}
	

}

/* End of file Model_role.php */
/* Location: ./application/models/Model_role.php */