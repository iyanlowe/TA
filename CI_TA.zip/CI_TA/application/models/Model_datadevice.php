<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_datadevice extends CI_Model {

	public function getAllDevice() {
		$this->db->join('typedevice', 'device.id_typedevice=typedevice.id_typedevice');
		return $this->db->get('device')->result();
	}
	public function getAllKategoriData() {

		return $this->db->get('kategori')->result();
	}
	public function getAllDataKategoriById($id) {
		$this->db->join('kategori', 'data_device.id_kategori=kategori.id_kategori');
		return $this->db->get_where('data_device', ['id_device' => $id])->result();
	}

	public function getAllDataKategori() {
		$this->db->join('kategori', 'data_device.id_kategori=kategori.id_kategori');
		return $this->db->get_where('data_device', ['id_device' => $id_device])->result();
	}

	public function getViewAllDataUjiById($id) {
		$this->db->join('data_uji', 'data_pengujian.id_ujidata=data_uji.id_ujidata');
		return $this->db->get_where('data_pengujian', ['id_pengujian' => $id])->result();
	}

	public function hapusdevice($id_device) {

		$this->db->delete('device', ['id_device' => $id_device]);
		$this->db->delete('data_device', ['id_device' => $id_device]);
	}

	public function hapusHasilUji($id_hasiluji) {
		$this->db->delete('data_hasil_uji', ['id_hasiluji' => $id_hasiluji]);
		$this->db->delete('hasil_uji', ['id_hasiluji' => $id_hasiluji]);
	}

	public function getDataDevice($id) {

		// $this->db->join('data_device', 'data_device.id_device=device.id_device');
		$this->db->join('typedevice', 'device.id_typedevice=typedevice.id_typedevice');
		
		return $this->db->get_where('device', ['id_device' => $id])->row_array();
	}

	public function ubahDataDevice($data)
	{
		$timekey = round(microtime(true) * 1000);
		$data = [

			'id_typedevice' => $this->input->post('id_typedev'),
			'kode_device' => $this->input->post('kode_device'),
			'timekey' => $timekey,
		];
		$this->db->where('id_device', $this->input->post('id_device'));
		$this->db->update('device', $data);
		
		$id_device = $this->db->get_where('device', ['timekey' => $timekey])->row()->id_device;
		$datakategori = $this->input->post('id_kate');
		$datas = [
			'id_device' => $id_device,
				// 'id_kategori' => $id_kategori,
				// 'nama_datauji' =>$dt
		];

		$this->db->where('id_device', $id_device);
		$this->db->update('data_device', $datas);

			//delete data device
		$this->db->delete('data_device', ['id_device' => $id_device]);

		$id_device = $this->db->get_where('device', ['timekey' => $timekey])->row()->id_device;
		$datakategori = $this->input->post('id_kate');
		// $namedatauji =$this->input->post('nama_datauji');
		foreach ($datakategori as $dk) {
			$result = [

				'id_device' => $id_device,
				'id_kategori' => $dk,
				// 'nama_datauji' =>$dt
			];
			$this->db->insert('data_device', $result);
		}

		$this->session->set_flashdata('message', 'Data Device updated!');
		redirect(base_url() . 'data/datadevice');
	}

}


