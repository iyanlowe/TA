<?php

defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

Class hasil_uji extends REST_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('api_model/Api_modelhasiluji');
	}

	public function index_get()
	{
		$id_hasiluji = $this->get('id_hasiluji');
		if ($id_hasiluji === null) {
			$hasil_uji = $this->Api_modelhasiluji->getHasilUji();
		}else{
			$hasil_uji = $this->Api_modelhasiluji->getHasilUji($id_hasiluji);
		}
		
		if ($hasil_uji) {
			$this->response([
				'status' => true,
				'data' => $hasil_uji
			], REST_Controller::HTTP_OK);
		}else{
			$this->response([
				'status' => FALSE,
				'message' => 'Data not found'
			], REST_Controller::HTTP_NOT_FOUND);
		}
	}

	public function index_post() {
		$date_created = date('d-m-Y');
		$data = [

			'id_device' => $this->post('id_device'),
			'date_created' => $date_created,
			'id_hasilpilih' => $this->post('hasil_uji'),
			'keterangan' => $this->post('keterangan')

		];
		if ($this->db->insert('hasil_uji', $data)) {
			$id_hasiluji = $this->db->get_where('hasil_uji', ['date_created' => $date_created])->row()->id_hasiluji;
			$datauji = $this->post('list_datauji');
			$arrayDU=json_decode($datauji);
			$i=0;
			foreach ($arrayDU as $du) {
				$datas = [

					'id_hasiluji' => $id_hasiluji,
					'id_ujidata' => $du,
				];
				$this->db->insert('data_hasil_uji', $datas);
				$i++;
			}


			if ($i==count($arrayDU)) {
				$this->response([
					'status' => true,
					'message' => 'new hasil uji has been created'
				], REST_Controller::HTTP_CREATED);
			} else{
				$this->response([
					'status' => FALSE,
					'message' => 'new data failed to created'
				], REST_Controller::HTTP_BAD_REQUEST);
			}
			return;
		} else{
			$this->response([
				'status' => FALSE,
				'message' => 'new data failed to created'
			], REST_Controller::HTTP_BAD_REQUEST);
			return;
		}

		

	}
}