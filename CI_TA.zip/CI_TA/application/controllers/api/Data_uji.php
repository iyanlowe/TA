<?php

defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

Class Data_uji extends REST_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('api_model/Api_modeldatauji');
	}
	public function index_get()
	{
		$id_ujidata = $this->get('id_ujidata');
		if ($id_ujidata === null) {
			$datauji = $this->Api_modeldatauji->getDatauji();
		}else{
			$datauji = $this->Api_modeldatauji->getDatauji($id_ujidata);
		}
		
		if ($datauji) {
			$this->response([
				'status' => true,
				'data' => $datauji
			], REST_Controller::HTTP_OK);
		}else{
			$this->response([
				'status' => FALSE,
				'message' => 'Data not found'
			], REST_Controller::HTTP_NOT_FOUND);
		}
	}

	public function index_delete()
	{
		$id_ujidata = $this->delete('id_ujidata');
		if ($id_ujidata === null) {
			$this->response([
				'status' => FALSE,
				'message' => 'Masukan Id dulu kawan'
			], REST_Controller::HTTP_BAD_REQUEST);
		}else{
			if ($this->Api_modeldatauji->deleteDatauji($id_ujidata) > 0)
			{
				$message = [
					'status' => true,
					'id_ujidata' => $id_ujidata,
					'message' => 'id deleted.'
				];
				$this->set_response($message, REST_Controller::HTTP_OK);

			}
			else
			{
				$this->response([
					'status' => FALSE,
					'message' => 'id tidak di temukan'
				], REST_Controller::HTTP_BAD_REQUEST);
			}
			
		}
	}

	public function index_post()
	{
		$data = [
			'nama_datauji' => $this->post('nama_datauji'),
			'id_kategori' => $this->post('id_kategori'),
		];

		if ($this->Api_modeldatauji->createDatauji($data) > 0) {
			$this->response([
				'status' => true,
				'message' => 'new data has been created'
			], REST_Controller::HTTP_CREATED);

		} else{
			$this->response([
				'status' => FALSE,
				'message' => 'new data failed to created'
			], REST_Controller::HTTP_BAD_REQUEST);
		}
	}

	public function index_put()
	{
		$id = $this->put('id_ujidata');
		$data = [
			'nama_datauji' => $this->post('nama_datauji'),
			'id_kategori' => $this->post('id_kategori'),
		];

		if ($this->Api_modeldatauji->updateDatauji($data, $id_ujidata) > 0) {
			$this->response([
				'status' => true,
				'message' => 'data has been updated'
			], REST_Controller::HTTP_OK);

		} else{
			$this->response([
				'status' => FALSE,
				'message' => 'data failed to updated'
			], REST_Controller::HTTP_BAD_REQUEST);
		}
	}
}