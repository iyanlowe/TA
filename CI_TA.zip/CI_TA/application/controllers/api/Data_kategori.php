<?php

defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

Class Data_kategori extends REST_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('api_model/Api_modelkategori');

	}
	public function index_get()
	{
		$id_kategori = $this->get('id_kategori');
		if ($id_kategori === null) {
			$kategori = $this->Api_modelkategori->getKategori();
		}else{
			$kategori = $this->Api_modelkategori->getKategori($id_kategori);
		}
		
		if ($kategori) {
			$this->response([
				'status' => true,
				'data' => $kategori
			], REST_Controller::HTTP_OK);
		}else{
			$this->response([
				'status' => FALSE,
				'message' => 'Data not found'
			], REST_Controller::HTTP_NOT_FOUND);
		}
	}

	public function index_delete()
	{
		$id_kategori = $this->delete('id_kategori');
		if ($id_kategori === null) {
			$this->response([
				'status' => FALSE,
				'message' => 'Masukan Id dulu kawan'
			], REST_Controller::HTTP_BAD_REQUEST);
		}else{
			if ($this->Api_modelkategori->deleteKategori($id_kategori) > 0)
			{
				$message = [
					'status' => true,
					'id_kategori' => $id_kategori,
					'message' => 'id deleted.'
				];
				$this->set_response($message, REST_Controller::HTTP_OK);

			}
			else
			{
				$this->response([
					'status' => FALSE,
					'message' => 'id tidak di temukan'
				], REST_Controller::HTTP_BAD_REQUEST);
			}
			
		}
	}

	public function index_post()
	{
		$data = [
			'nama_kategori' => $this->post('nama_kategori'),
			'urutan_kategori' => $this->post('urutan_kategori'),
			'keterangan' => $this->post('keterangan'),
		];

		if ($this->Api_modelkategori->createKategori($data) > 0) {
			$this->response([
				'status' => true,
				'message' => 'new data has been created'
			], REST_Controller::HTTP_CREATED);

		} else{
			$this->response([
				'status' => FALSE,
				'message' => 'new data failed to created'
			], REST_Controller::HTTP_BAD_REQUEST);
		}
	}

	public function index_put()
	{
		$id_kategori = $this->put('id_kategori');
		$data = [
			'nama_kategori' => $this->post('nama_kategori'),
			'urutan_kategori' => $this->post('urutan_kategori'),
			'keterangan' => $this->post('keterangan'),
		];


		if ($this->Api_modelkategori->updateKategori($data, $id_kategori) > 0) {
			$this->response([
				'status' => true,
				'message' => 'data has been updated'
			], REST_Controller::HTTP_OK);

		} else{
			$this->response([
				'status' => FALSE,
				'message' => 'data failed to updated'
			], REST_Controller::HTTP_BAD_REQUEST);
		}
	}
}