<?php

defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

Class Type_device extends REST_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('api_model/Api_modeldevice');
	}
	public function index_get()
	{
		$id_typedevice = $this->get('id_typedevice');
		if ($id_typedevice === null) {
			$device = $this->Api_modeldevice->getDevice();
		}else{
			$device = $this->Api_modeldevice->getDevice($id_typedevice);
		}
		
		if ($device) {
			$this->response([
				'status' => true,
				'data' => $device
			], REST_Controller::HTTP_OK);
		}else{
			$this->response([
				'status' => FALSE,
				'message' => 'Data not found'
			], REST_Controller::HTTP_NOT_FOUND);
		}
	}

	public function index_delete()
	{
		$id_typedevice = $this->delete('id_typedevice');
		if ($id_typedevice === null) {
			$this->response([
				'status' => FALSE,
				'message' => 'Masukan Id dulu kawan'
			], REST_Controller::HTTP_BAD_REQUEST);
		}else{
			if ($this->Api_modeldevice->deleteDevice($id_typedevice) > 0)
			{
				$message = [
					'status' => true,
					'id_typedevice' => $id_typedevice,
					'message' => 'id deleted.'
				];
				$this->set_response($message, REST_Controller::HTTP_OK);

			}
			else
			{
				$this->response([
					'status' => FALSE,
					'message' => 'id tidak di temukan'
				], REST_Controller::HTTP_BAD_REQUEST);
			}
			
		}
	}

	public function index_post()
	{
		$data = [
			'nama_typedevice' => $this->post('nama_typedevice'),
			'ket_typedevice' => $this->post('ket_typedevice')
		];

		if ($this->Api_modeldevice->createDevice($data) > 0) {
			$this->response([
				'status' => true,
				'message' => 'new data has been created'
			], REST_Controller::HTTP_CREATED);

		} else{
			$this->response([
				'status' => FALSE,
				'message' => 'new data failed to created'
			], REST_Controller::HTTP_BAD_REQUEST);
		}
	}

	public function index_put()
	{
		$id = $this->put('id_typedevice');
		$data = [
			'nama_typedevice' => $this->put('nama_typedevice'),
			'ket_typedevice' => $this->put('ket_typedevice')
		];

		if ($this->Api_modeldevice->updateDevice($data, $id_typedevice) > 0) {
			$this->response([
				'status' => true,
				'message' => 'data has been updated'
			], REST_Controller::HTTP_OK);

		} else{
			$this->response([
				'status' => FALSE,
				'message' => 'data failed to updated'
			], REST_Controller::HTTP_BAD_REQUEST);
		}
	}
}