<?php

defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

Class Data_device extends REST_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('api_model/Api_modeldatadevice');

	}

	public function index_get()
	{
		$id_device = $this->get('id_device');
		if ($id_device === null) {
			$device = $this->Api_modeldatadevice->getDevice();
			$i=0;
			foreach ($device as $dt) {
				$kode_device[$i]=$dt->kode_device;
				$i++;
			}
		}else{
			$device = $this->Api_modeldatadevice->getDevice($id_device);
		}
		
		if ($device) {
			$this->response([
				'status' => true,
				'kode_device' => $kode_device
			], REST_Controller::HTTP_OK);
		}else{
			$this->response([
				'status' => FALSE,
				'message' => 'Data not found'
			], REST_Controller::HTTP_NOT_FOUND);
		}
	}



	public function check_post()
	{
		$nomorsn = $this->post('kode_device');
		$typedevice = $this->post('id_typedevice');

		$device = $this->db->get_where('device', ['kode_device' => $nomorsn])->row_array(); 
		$id_hasiluji = $this->db->get_where('device', ['kode_device' => $nomorsn])->row()->id_device;
		$hasil_uji = $this->db->get_where('hasil_uji', ['id_device' => $id_hasiluji])->row_array();
		//jika SN ada
		if ($device) {
			if ($device['id_typedevice'] == $typedevice) {

				if ($hasil_uji['id_hasilpilih'] !== NULL) {
					$this->response([
						'status' => FALSE,
						'message' => 'Device Sudah Diuji'
					], REST_Controller::HTTP_NOT_FOUND);
				}else{

					$this->response([
						'status' => true,
						'message' => 'Data Device Siap Uji'
					], REST_Controller::HTTP_OK);
				}
			}else{
				{
					$this->response([
						'status' => FALSE,
						'message' => 'type device tidak cocok dengan nomor SN yang dipilih, harap cek kembali!'
					], REST_Controller::HTTP_NOT_FOUND);
				}
			}
			
		}else{
			$this->response([
				'status' => FALSE,
				'message' => 'Nomor SN Tidak Terdaftar!'
			], REST_Controller::HTTP_NOT_FOUND);
		}

	}

	public function detaildevice_post(){
		$nomorsn = $this->post('kode_device');
		$deviceDet=$this->Api_modeldatadevice->getDataDeviceById($nomorsn);

		if(count($deviceDet)>0){
			$category=$this->Api_modeldatadevice->getAllDataKategoriById($deviceDet->id_device);
			$uji=$this->Api_modeldatadevice->getDeviceHasilUji($deviceDet->id_device);
			if(count($uji)>0){
				$deviceUji['status_uji']='1';
				$deviceUji['hasil_uji']=$uji->nama_hasilpilih;
			}else{
				$deviceUji['status_uji']='0';
				
			}
			$i=0;
			foreach ($category as $dt) {
				
				$datauji=$this->Api_modeldatadevice->getAllDataUjiByCat($dt->id_kategori);
				$j=0;
				foreach ($datauji as $dts) {
					$devCat[$dt->nama_kategori][$j]=$dts->id_ujidata.'-'.$dts->nama_datauji;
					$j++;
				}
				$i++;
			}


			$this->response([
						'status' => true,
						'device_uji'=>$deviceUji,
						'device_detail'=>$deviceDet,
						'device_cat'=>$devCat,
						
					], REST_Controller::HTTP_OK);
		}else{

			$this->response([
						'status' => false,
					], REST_Controller::HTTP_OK);
		}
	}
	
}

