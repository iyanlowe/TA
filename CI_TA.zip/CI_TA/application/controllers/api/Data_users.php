<?php

defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

Class Data_users extends REST_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('api_model/Api_modeldatausers');
	}
	
	public function index_get()
	{
		$id = $this->get('id');
		if ($id === null) {
			$users = $this->Api_modeldatausers->getUsers();
		}else{
			$users = $this->Api_modeldatausers->getUsers($id);
		}
		
		if ($users) {
			$this->response([
				'status' => true,
				'data' => $users
			], REST_Controller::HTTP_OK);
		}else{
			$this->response([
				'status' => FALSE,
				'message' => 'Data not found'
			], REST_Controller::HTTP_NOT_FOUND);
		}
	}

	public function login_post()
	{

		$email = $this->post('email');
		$password = $this->post('password');

		$user = $this->db->get_where('user', ['email' => $email])->row_array(); 
		
		if ($user) {
            //jika user active
			if ($user['active_id'] == 1) {
                //cek password
				if (password_verify($password, $user['password'])) {

					if ($user['role_id'] ==  2) {
						$this->response([
							'status' => true,
							'message' => 'login sukses'
						], REST_Controller::HTTP_OK);
					}else{
						$this->response([
							'status' => FALSE,
							'message' => 'login gagal'
						], REST_Controller::HTTP_NOT_FOUND);
					}
				}else{
					$this->response([
						'status' => FALSE,
						'message' => 'Wrong Password'
					], REST_Controller::HTTP_NOT_FOUND);
				}
			}else{
				$this->response([
					'status' => FALSE,
					'message' => 'Email Belum di aktifasi'
				], REST_Controller::HTTP_NOT_FOUND);
			}
		}else{
			$this->response([
				'status' => FALSE,
				'message' => 'Email belum terdaftar'
			], REST_Controller::HTTP_NOT_FOUND);
		}
	}

	public function registrasi_post() {

		$email = $this->input->post('email', true);
		$password = $this->post('password');
		$user = $this->db->get_where('user', ['email' => $email])->row_array(); 

		if ($user) {
			$this->response([
				'status' => FALSE,
				'message' => 'email sudah ada'
			], REST_Controller::HTTP_BAD_REQUEST);
		}

	else{

		$data = [
			'name' => htmlspecialchars($this->post('name', true)),
			'email' => htmlspecialchars($email),
			'image' => 'default.jpg',
			'password' => password_hash($password, PASSWORD_DEFAULT),
			'role_id' => 2,
			'active_id' => 0,
			'date_created' => time()
		];


		if ($this->Api_modeldatausers->createUsers($data) > 0) {
		$this->response([
			'status' => true,
			'message' => 'Selamat akun anda telah dibuat'
		], REST_Controller::HTTP_CREATED);
	}else{
			$this->response([
				'status' => true,
				'message' => 'akun anda gagal dibuat'
			], REST_Controller::HTTP_NOT_FOUND);
		}
	}
}
}
	


