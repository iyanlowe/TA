<?php

defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

Class Data_pengujian extends REST_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('api_model/Api_modeldatapengujian');
	}
	public function index_get()
	{
		$id_pengujian = $this->get('id_pengujian');
		if ($id_pengujian === null) {
			$datapengujian = $this->Api_modeldatapengujian->getDatapengujian();
		}else{
			$datapengujian = $this->Api_modeldatapengujian->getDatapengujian($id_pengujian);
		}
		
		if ($datapengujian) {
			$this->response([
				'status' => true,
				'data' => $datapengujian
			], REST_Controller::HTTP_OK);
		}else{
			$this->response([
				'status' => FALSE,
				'message' => 'Data not found'
			], REST_Controller::HTTP_NOT_FOUND);
		}
	}

	public function index_delete()
	{
		$id_pengujian = $this->delete('id_pengujian');
		if ($id_pengujian === null) {
			$this->response([
				'status' => FALSE,
				'message' => 'Masukan Id dulu kawan'
			], REST_Controller::HTTP_BAD_REQUEST);
		}else{
			if ($this->Api_modeldatapengujian->deleteDatauji($id_pengujian) > 0)
			{
				$message = [
					'status' => true,
					'id_pengujian' => $id_pengujian,
					'message' => 'id deleted.'
				];
				$this->set_response($message, REST_Controller::HTTP_OK);

			}
			else
			{
				$this->response([
					'status' => FALSE,
					'message' => 'id tidak di temukan'
				], REST_Controller::HTTP_BAD_REQUEST);
			}
			
		}
	}

	public function index_post()
	{
		$data = [
			'id_pengujian' => $this->post('id_pengujian'),
			'id_ujidata' => $this->post('id_ujidata'),
			'nama_datauji' => $this->post('nama_datauji')
		];

		if ($this->Api_modeldatapengujian->createDatapengujian($data) > 0) {
			$this->response([
				'status' => true,
				'message' => 'new data has been created'
			], REST_Controller::HTTP_CREATED);

		} else{
			$this->response([
				'status' => FALSE,
				'message' => 'new data failed to created'
			], REST_Controller::HTTP_BAD_REQUEST);
		}
	}

	public function index_put()
	{
		$id_pengujian = $this->put('id_pengujian');
		$data = [
			'id_pengujian' => $this->post('id_pengujian'),
			'id_ujidata' => $this->post('id_ujidata'),
		];

		if ($this->Api_modeldatapengujian->updateDatapengujian($data, $id_pengujian) > 0) {
			$this->response([
				'status' => true,
				'message' => 'data has been updated'
			], REST_Controller::HTTP_OK);

		} else{
			$this->response([
				'status' => FALSE,
				'message' => 'data failed to updated'
			], REST_Controller::HTTP_BAD_REQUEST);
		}
	}
}