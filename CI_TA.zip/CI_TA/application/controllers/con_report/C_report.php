<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_report extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('Modelkategori_produk');
		$this->load->model('Model_hasiluji');
		$this->load->model('Model_datadevice');
	}

	public function index()
	{
		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('data/report/report_data', $data);
		$this->load->view('templates/footer');
	}

	public function datareport()
	{
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$data['datadevice'] = $this->Model_datadevice->getAllDevice();
		$data['hasil_uji'] = $this->Model_hasiluji->getAllDataDevice();
		
		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('data/report/report_data', $data);
		$this->load->view('templates/footer');

	}

	public function historyreport(){
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('data/report/history_report', $data);
		$this->load->view('templates/footer');

	}

	public function tambahreportdata() {
		$date_created = time();
		$data = [

			'id_device' => $this->input->post('id_device'),
			'date_created' => $date_created,
			'hasil_uji' => $this->input->post('hasil_uji'),
			'keterangan' => $this->input->post('keterangan'),
		
		];
		$this->db->insert('hasil_uji', $data);
		$id_hasiluji = $this->db->get_where('hasil_uji', ['date_created' => $date_created])->row()->id_hasiluji;
		$datauji = $this->input->post('id_ujidata');

			foreach ($datauji as $du) {
				$datas = [

					'id_hasiluji' => $id_hasiluji,
					'id_ujidata' => $du,
				];
				$this->db->insert('data_hasil_uji', $datas);
			}

		$this->session->set_flashdata('message', 'New Data report Added!');
		redirect(base_url() . 'data/report/report_data');

	}

	public function hapushasiluji($id_hasiluji) {
		$this->Model_datadevice->hapusHasilUji($id_hasiluji);
		$this->session->set_flashdata('message', 'Data Telah Berhasil Di Hapus!');
		redirect('con_report/C_report/datareport');
	}

	
}
