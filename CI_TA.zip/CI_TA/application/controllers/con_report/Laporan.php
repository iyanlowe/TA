<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporan extends CI_Controller 

{
	function __construct(){
		parent::__construct();
		$this->load->model('Model_hasiluji');
		$this->load->model('Model_datadevice');
	}
	public function index()
	{
		$this->load->Library('mypdf');
		$data['hasil_uji'] = $this->Model_hasiluji->getAllDataDevice();
		$this->mypdf->generate('laporan/mypdf', $data);
	}

	public function cetakreport()
	{
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$data['datadevice'] = $this->Model_datadevice->getAllDevice();
		$data['hasil_uji'] = $this->Model_hasiluji->getAllDataDevice();
		$data['date'] = $this->db->get('hasil_uji')->result();
		
		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('laporan/cetaklaporan', $data);
		$this->load->view('templates/footer');	
	}

	public function filter()
	{
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$data['datadevice'] = $this->Model_datadevice->getAllDevice();

		$data['date'] = $this->db->get('hasil_uji')->result();
		$date = $this->input->post('date');
		$data['filterhasil'] = $this->db->get_where('hasil_uji', ['id_hasiluji' => $date])->result();
	
			$this->load->view('templates/header', $data);
			$this->load->view('templates/sidebar', $data);
			$this->load->view('templates/topbar', $data);
			$this->load->view('laporan/filterhasil', $data);
			$this->load->view('templates/footer');	
	
		
	}
}