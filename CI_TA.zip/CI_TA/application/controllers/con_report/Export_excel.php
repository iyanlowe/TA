<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//load Spout Library
require_once APPPATH.'libraries/spout-3.0.1/spout-3.0.1/src/Spout/Autoloader/autoload.php';

use Box\Spout\Writer\Common\Creator\WriterEntityFactory;
use Box\Spout\Common\Entity\Row;

class Export_excel extends CI_Controller {

    function __construct()
    {
        parent::__construct();
        //load model
        $this->load->model('Model_hasiluji');
    }

    public function index()
    {
        $this->load->view('laporan/export');
    }

    public function export_data()
    {
        //ambil data
        $get  = $this->Model_hasiluji->getAll();
        $jum =  $this->Model_hasiluji->total_rowsreport();
        $filePath = 'file_excel.xlsx';
// $writer = WriterEntityFactory::createXLSXWriter();
        // var_dump(sys_get_temp_dir()); exit;
        // var_dump($get); exit;

        //validasi jumlah data
        if ($jum > 0)
        {
            $writer = WriterEntityFactory::createXLSXWriter();
            // $writer->openToFile($filePath);

            // $writer = WriterEntityFactory::createXLSXWriter();
            $writer->openToBrowser("Report_QualityControlSystem.xlsx");

            // $writer->openToFile($filePath);
            //silahkan sobat sesuaikan dengan data yang ingin sobat tampilkan
             $header = [
                WriterEntityFactory::createCell('No'),
                WriterEntityFactory::createCell('Nomor SN'),
                WriterEntityFactory::createCell('Nama Device'),
                WriterEntityFactory::createCell('Date Created'),
                WriterEntityFactory::createCell('Hasil Uji'),
                WriterEntityFactory::createCell('Keterangan')
                ];
           
             $singleRow = WriterEntityFactory::createRow($header);
            $writer->addRow($singleRow);

            $data   = array(); //siapkan variabel array untuk menampung data
            $no     = 1;
 
            //looping pembacaan data
            foreach ($get as $key)
            {
                //masukkan data dari database ke variabel array
                //silahkan sobat sesuaikan dengan nama field pada tabel database
                $anggota = [
                    WriterEntityFactory::createCell($no++),
                    WriterEntityFactory::createCell($key->kode_device),
                    WriterEntityFactory::createCell($key->nama_typedevice),
                    WriterEntityFactory::createCell($key->date_created),
                    WriterEntityFactory::createCell($key->nama_hasilpilih),
                    WriterEntityFactory::createCell($key->keterangan),
                ];

                $data[] = WriterEntityFactory::createRow($anggota);
                   
                 // array_push($data, $anggota); //masukkan variabel array anggota ke variabel array data
            }
 
            $writer->addRows($data); // tambahkan row untuk data anggota
 
         
            $writer->close(); //tutup spout writer
        }
        else
        {
            echo "Data tidak ditemukan";
        }
    }
}