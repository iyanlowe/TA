<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller 
{

	public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');

		
	}

	public function index()
	{
		if ($this->session->userdata('email')) {
			redirect('admin');
		}
		$this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email');
		$this->form_validation->set_rules('password', 'Password', 'trim|required');

		if ($this->form_validation->run() == false) {
			$data['title'] = 'Login Page';
			$this->load->view('layout/header', $data);
			$this->load->view('auth/login');
			$this->load->view('layout/footer');
		}else{
			$this->_login();
		}
	}

	private function _login(){


		$email = $this->input->post('email');
		$password = $this->input->post('password');

		$user = $this->db->get_where('user', ['email' => $email])->row_array(); 
		//usernya ada
		if ($user) {
			//jika user active
			if ($user['active_id'] == 1) {
				//cek password
				if (password_verify($password, $user['password'])) {
					$data = [
						'email' => $user['email'],
						'role_id' => $user['role_id']
					];
					$this->session->set_userdata($data);
					if ($user['role_id'] ==  1) {
						redirect('admin');
					}if ($user['role_id'] == 2) {
						redirect('penguji/penguji');
					}if ($user['role_id'] ==  3) {
						redirect('petugas/petugas2');
					}if ($user['role_id'] ==  4) {
						redirect('petugas/petugas3');
					}
					else {
						redirect('petugas/petugas4');
					}
				}else{
					$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Wrong password!<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
						</button></div>');
					redirect('auth');
				}
			}else{
				$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">This Email is not been activited!<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
					</button></div>');
				redirect('auth');
			}
		}else{

			$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Email is not registered!<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button></div>');
			redirect('auth');
		}
	}

	public function register()
	{
		if ($this->session->userdata('email')) {
			redirect('admin');
		}

		$role = $this->model_role->listing();
		if ($this->session->userdata('email')) {
			redirect('admin');
		}
		 $this->form_validation->set_rules('fname', 'Nama Depan', 'trim|required|is_unique[user.fname]',['is_unique'=>'Nama Depan Sudah terdaftar']);
   		 $this->form_validation->set_rules('lname', 'Nama Belakang', 'trim|required|is_unique[user.lname]',['is_unique'=>'Nama Belakang Sudah terdaftar']);
		$this->form_validation->set_rules('email', 'Alamat Email', 'trim|required|valid_email|is_unique[user.email]',['is_unique'=>'Email Sudah terdaftar']);
    	$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[2]',['min_length'=>'Password Terlalu Pendek']);
    	$this->form_validation->set_rules('confpass', 'Configruasi Password', 'trim|required|matches[password]',['matches' =>'Password Tidak Sama']);

		if ($this->form_validation->run() == false) {
			$data['title'] = 'Registration Page';
			$this->load->view('templates/auth_header',$data);
			$this->load->view('auth/register');
			$this->load->view('templates/auth_footer');

		} else {
			$email = $this->input->post('email', true);
			$data = [
				'fname' => htmlspecialchars($this->input->post('fname',true)),
                'lname' => htmlspecialchars($this->input->post('lname',true)),
                'email' => htmlspecialchars($email),
				'image' => 'default.jpg',
				'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
				'role_id' => htmlspecialchars($this->input->post('role_id',true)),
				'active_id' => 0,
				'date_created' => time()
			];

			//siapkan token
			$token = base64_encode(random_bytes(32));
			$user_token = [
				'email' => $email,
				'token' => $token,
				'date_created' => time()
			];


			$this->db->insert('user', $data);
			$this->db->insert('user_token', $user_token);

			$this-> _sendEmail($token, 'verify');
			$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Congratulation! Your Account Has Been Created. Please Activate Your Account<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button></div>');  
			redirect('auth');
		}
		
	}


	private function _sendEmail($token, $type)
	{

		$config['protocol']    = 'smtp';
		$config['smtp_host']    = 'ssl://smtp.googlemail.com';
		$config['smtp_port']    = '465';
		$config['smtp_timeout'] = '7';
		$config['smtp_user']    = 'iyanslalutertawa@gmail.com';
		$config['smtp_pass']    = 'karacter12345';
		$config['charset']    = 'utf-8';
		$config['newline']    = "\r\n";
		$config['mailtype'] = 'html'; 
		$config['validation'] = FALSE;

		$this->email->initialize($config);
		$this->email->from('iyanslalutertawa@gmail.com','Badan Penanggulangan Bencana Daerah');
		$this->email->to($this->input->post('email')); 

		if ($type == 'verify') {
			$this->email->subject('Account Verification');
			$this->email->message('Click this link to verify your account : <a href="'. base_url() . 'auth/verify?email=' . $this->input->post('email') . '&token=' . urlencode($token) . '">Active</a>'); 
		}else if ($type == 'forgot') {
			$this->email->subject('Reset Password');
			$this->email->message('Click this link to reset your account : <a href="'. base_url() . 'auth/resetpassword?email=' . $this->input->post('email') . '&token=' . urlencode($token) . '">Reset Password Akun</a>'); 
		}

		$send = $this->email->send();
		if($send) {
			return true;
		} else {
			echo $this->email->print_debugger();

		}

	}

	public function verify()
	{
		$email = $this->input->get('email');
		$token = $this->input->get('token');

		$user = $this->db->get_where('user', ['email' => $email])->row_array();

		if ($user) {
			$user_token = $this->db->get_where('user_token', ['token' => $token])->row_array();

			if ($user_token) {
				if (time() - $user_token['date_created'] < (60*60*24)) {
					$this->db->set('active_id', 1);
					$this->db->where('email', $email);
					$this->db->update('user');
					$this->db->delete('user_token', ['email' => $email]);
					$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">'.$email.' has been activated! plase login.<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
						</button></div>');  
					redirect('auth');
				}else{
					$this->db->delete('user', ['email' => $email]);
					$this->db->delete('user_token', ['email' => $email]);
					$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Token sudah expired kawan!<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
						</button></div>');  
					redirect('auth');
				}
			}else{
				$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Token anda tidak benar kawan!<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
					</button></div>');  
				redirect('auth');
			}

		}else {
			$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Email anda tidak benar kawan!<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button></div>');  
			redirect('auth');
		}
	}

	public function logout()
	{
		if ($this->session->userdata('email') == "") {
			redirect('auth');
		}
		$this->session->unset_userdata('email');
		$this->session->unset_userdata('role_id');

		$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">You Have Been Logged out!<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">&times;</span>
			</button></div>');  
		redirect('auth');
	}

	public function forgotpassword()
	{
		if ($this->session->userdata('email')) {
			redirect('admin');
		}
		$this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email');

		if ($this->form_validation->run() == false) {
			$data['title'] = 'Forgotted Password Page';
			$this->load->view('layout/header', $data);
			$this->load->view('auth/login');
			$this->load->view('layout/footer');
		}else{
			$email = $this->input->post('email');
			$user = $this->db->get_where('user', ['email' => $email, 'active_id' => 1])->row_array();

			if ($user) {
				$token = base64_encode(random_bytes(32));
				$user_token = [
					'email' => $email,
					'token' => $token,
					'date_created' => time()
				];

				$this->db->insert('user_token', $user_token);
				$this-> _sendEmail($token, 'forgot');
				$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Check email to Reset Your Password!<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
					</button></div>');  
				redirect('auth');
			}else{

				$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Email is not register or activated!<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
					</button></div>');  
				redirect('auth/forgotpassword');
			}
		}
	}

	//untuk halaman forgot password
  public function resetpassword()
  {
  	if ($this->session->userdata('email')) {
			redirect('admin');
		}
    $email = $this->input->get('email');
    $token = $this->input->get('token');

    //cek email yang lupa password
    $user = $this->db->get_where('user',['email'=> $email])->row_array();
      //kalo ada ambil user token
      if ($user) {
        $user_token = $this->db->get_where('user_token',['token'=> $token])->row_array();
          //token ada
          if ($user_token) {
              //membuat session biar server saja tahu
              $this->session->set_userdata('reset_email',$email);
              //panggil metode baru untuk halaman
              $this->changepassword();
            
          }else {
            $this->session->set_flashdata('message','<div class="alert alert-danger" role="alert">
                                          Reset Password Failed! Wrong Token</div>');
            redirect('auth');
          }

        
      } else {
        $this->session->set_flashdata('message','<div class="alert alert-danger" role="alert">
                                          Reset Password Failed! Wrong Email</div>');
        redirect('auth');
      }
  }

	public function changepassword()
	{
		if (!$this->session->userdata('reset_email')) {
			redirect('auth');
		}
		$this->form_validation->set_rules('password', 'New Password', 'required|trim|min_length[8]|matches[confpass]', [
			'matches' => 'Password dont matches!',
			'min_length' => 'Password too short!'
		]);
		$this->form_validation->set_rules('confpass', 'Confirm New Password', 'required|trim|matches[password]');

		if ($this->form_validation->run() == false) {
			$data['title'] = 'Change Password Page';
			$this->load->view('layout/header', $data);
			$this->load->view('auth/change_password');
			$this->load->view('layout/footer');
		}else{
					// pssword sudah benar
			$password = password_hash($this->input->post('password'), PASSWORD_DEFAULT);
			$email = $this->session->userdata('reset_email');
			$this->db->set('password', $password);
			$this->db->where('email', $email);
			$this->db->update('user');

			$this->session->unset_userdata('reset_email');

			$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Password Changed! Please login. <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button></div>');
			redirect('auth');
		}
	}
	
} 