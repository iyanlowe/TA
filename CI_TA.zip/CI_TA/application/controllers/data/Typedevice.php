<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Typedevice extends CI_Controller {

	function __construct() {
		parent::__construct();
		$this->load->model('Model_typedevice');
	}

	public function index() {
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$data['type_device'] = $this->Model_typedevice->getAllTypeDevice();

		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('data/typedevice', $data);
		$this->load->view('templates/footer');

	}

	public function tambahtypedevice()
	{
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$data['type_device'] = $this->Model_typedevice->getAllTypeDevice();
		
		$this->form_validation->set_rules('nama_type', 'Nama_Type', 'required|is_unique[typedevice.nama_typedevice]', [
			'is_unique' => 'Type device sudah ada!'
		]);
		$this->form_validation->set_rules('ket_type', 'Ket_type', 'required');

		if ($this->form_validation->run() == false) {
			$this->load->view('templates/header', $data);
			$this->load->view('templates/sidebar', $data);
			$this->load->view('templates/topbar', $data);
			$this->load->view('data/typedevice', $data);    
			$this->load->view('templates/footer');
			$this->session->set_flashdata('message-danger', 'Harap cek kembali inputan anda!');
			// redirect('data/typedevice');

		} else {
			$this->Model_typedevice->tambahTypeDevice();
			$this->session->set_flashdata('message', 'New Type Device Added!');
			redirect('data/typedevice');
		}
	}

	public function hapustypedevice($id_typedevice) {
		$this->Model_typedevice->hapusTypeDevice($id_typedevice);
		$this->session->set_flashdata('message', 'Data Telah Berhasil Di Hapus!');
		redirect('data/typedevice');
	}



}