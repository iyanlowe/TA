<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Managdata extends CI_Controller {

	function __construct() {
		parent::__construct();
		$this->load->model('Modelkategori_produk');
		$this->load->model('Modelmanag_data');
		$this->load->model('Modeldata_uji');
		$this->load->model('Model_typedevice');
		$this->load->model('Modeldata_users');
	}


	public function detailkategori($id_kategori) {
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$data['dataproduk'] = $this->db->get('data_produk')->result_array();
		$data['dataproduks'] = $this->Modelkategori_produk->getAllProduks();
		$data['kategori'] = $this->db->get('kategori')->result_array();
		$data['data_produk'] = $this->Modelmanag_data->getDataProdukById($id_kategori);

		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('data/detailkategori', $data);
		$this->load->view('templates/footer');
	}

	public function edit($id_produk) {
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$data['data_produk'] = $this->Modelmanag_data->getDataProdukById($id_produk);
		$data['dataproduk'] = $this->Modelkategori_produk->getAllProduk();
		$data['kategori'] = $this->db->get('kategori')->result();

		$this->form_validation->set_rules('kode_produk', 'Kode_Produk', 'required');
		$this->form_validation->set_rules('nama_produk', 'Nama_produk', 'required');
		$this->form_validation->set_rules('id_kat', 'Id_Kat', 'required');
		$this->form_validation->set_rules('keterangan_produk', 'Keterangan_produk', 'required');

		if ($this->form_validation->run() == false) {
			$this->load->view('templates/header', $data);
			$this->load->view('templates/sidebar', $data);
			$this->load->view('templates/topbar', $data);
			$this->load->view('data/editproduk', $data);
			$this->load->view('templates/footer');
		} else {
			$this->Modelmanag_data->ubahDataProduk();
			redirect('data/managdata/data');
			$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data telah diubah!<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button></div>');
		}

	}

}