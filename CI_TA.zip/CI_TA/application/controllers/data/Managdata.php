<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Managdata extends CI_Controller {

	function __construct() {
		parent::__construct();
		$this->load->model('Modelkategori_produk');
		$this->load->model('Modelmanag_data');
		$this->load->model('Modeldata_uji');
		$this->load->model('Model_typedevice');
		$this->load->model('Modeldata_users');
	}

	public function index() {
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('data/tambahdata', $data);
		$this->load->view('templates/footer');

	}

	public function data() {
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$data['dataproduk'] = $this->Modelkategori_produk->getAllProduks();
		$data['kategori'] = $this->db->get('kategori')->result();

		$this->form_validation->set_rules('kode_produk', 'Kode_Produk', 'required');
		$this->form_validation->set_rules('nama_produk', 'Nama_produk', 'required');
		$this->form_validation->set_rules('id_kat', 'Id_Kat', 'required');
		$this->form_validation->set_rules('keterangan_produk', 'Keterangan_produk', 'required');

		if ($this->form_validation->run() == false) {
			$this->load->view('templates/header', $data);
			$this->load->view('templates/sidebar', $data);
			$this->load->view('templates/topbar', $data);
			$this->load->view('data/dataproduk', $data);
			$this->load->view('templates/footer');
		} else {
			$this->Modelmanag_data->getAllData();
			$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">New Data Produk Added!<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button></div>');
			redirect('data/managdata/data');
		}

	}

	public function kategoridata() {
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		// $data['dataproduk'] = $this->db->get('data_produk')->result_array();
		$data['kategori'] = $this->db->get('kategori')->result_array();

		$this->form_validation->set_rules('nama_kategori', 'Nama_Kategori', 'required|is_unique[kategori.nama-kategori]', [
			'is_unique' => 'Kategori sudah ada!'
		]);
		$this->form_validation->set_rules('keterangan', 'Keterangan', 'required');

		if ($this->form_validation->run() == false) {
			$this->load->view('templates/header', $data);
			$this->load->view('templates/sidebar', $data);
			$this->load->view('templates/topbar', $data);
			$this->load->view('data/kategoriproduk', $data);
			$this->load->view('templates/footer');
		} else {
			$this->Modelkategori_produk->tambahKategori();
			$this->session->set_flashdata('message', 'New kategori Added!');
			redirect('data/managdata/kategoridata');
		}

	}

	public function hapus($id_produk) {
		$this->Modelmanag_data->hapusDataProduk($id_produk);
		$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Data Telah Berhasil Di Hapus!<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">&times;</span>
			</button></div>');
		redirect('data/managdata/data');
	}

	public function hapuskategori($id_kategori) {
		$this->Modelkategori_produk->hapusDataKategori($id_kategori);
		$this->session->set_flashdata('message', 'Data Telah Berhasil Di Hapus!');
		redirect('data/managdata/kategoridata');
	}

	public function detailkategori($id_kategori) {
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$data['dataproduk'] = $this->db->get('data_produk')->result_array();
		$data['dataproduks'] = $this->Modelkategori_produk->getAllProduks();
		$data['kategori'] = $this->db->get('kategori')->result_array();
		$data['data_kategori'] = $this->Modelkategori_produk->getDataProdukById($id_kategori);

		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('data/kategori/detailkategori', $data);
		$this->load->view('templates/footer');
	}

	public function detail($id_produk) {
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$data['dataproduk'] = $this->db->get('data_produk')->result_array();
		$data['dataproduks'] = $this->Modelkategori_produk->getAllProduks();
		$data['kategori'] = $this->db->get('kategori')->result_array();
		$data['data_produk'] = $this->Modelmanag_data->getDataProdukById($id_produk);

		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('data/detailproduk', $data);
		$this->load->view('templates/footer');
	}

		public function editkategori($id_kategori) {
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$data['data_kategori'] = $this->Modelkategori_produk->getDataProdukById($id_kategori);
		$data['kategori'] = $this->db->get('kategori')->result();

		$this->form_validation->set_rules('nama_kategori', 'Nama Kategori', 'required');
		$this->form_validation->set_rules('keterangan', 'Keterangan', 'required');

		if ($this->form_validation->run() == false) {
			$this->load->view('templates/header', $data);
			$this->load->view('templates/sidebar', $data);
			$this->load->view('templates/topbar', $data);
			$this->load->view('data/kategori/editkategori', $data);
			$this->load->view('templates/footer');
		} else {
			$this->Modelkategori_produk->ubahDataKategori();
			$this->session->set_flashdata('message', 'Data telah diubah!');
			redirect('data/managdata/kategoridata');
		}

	}

	public function edit($id_produk) {
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$data['data_produk'] = $this->Modelmanag_data->getDataProdukById($id_produk);
		$data['dataproduk'] = $this->Modelkategori_produk->getAllProduk();
		$data['kategori'] = $this->db->get('kategori')->result();

		$this->form_validation->set_rules('kode_produk', 'Kode_Produk', 'required');
		$this->form_validation->set_rules('nama_produk', 'Nama_produk', 'required');
		$this->form_validation->set_rules('id_kat', 'Id_Kat', 'required');
		$this->form_validation->set_rules('keterangan_produk', 'Keterangan_produk', 'required');

		if ($this->form_validation->run() == false) {
			$this->load->view('templates/header', $data);
			$this->load->view('templates/sidebar', $data);
			$this->load->view('templates/topbar', $data);
			$this->load->view('data/editproduk', $data);
			$this->load->view('templates/footer');
		} else {
			$this->Modelmanag_data->ubahDataProduk();
			redirect('data/managdata/data');
			$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data telah diubah!<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button></div>');
		}

	}

	public function datausers() {
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$data['users'] = $this->db->get('user')->result_array();

		$this->form_validation->set_rules('nama_pelanggan', 'Kode_Produk', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email|is_unique[pelanggan.email]', [
			'is_unique' => 'email wis ready',
		]);
		$this->form_validation->set_rules('password', 'Password', 'required|trim|min_length[8]', [
			'min_length' => 'Password too short!',
		]);
		$this->form_validation->set_rules('telepon', 'Telepon', 'required');
		$this->form_validation->set_rules('alamat', 'Alamat', 'required');

		if ($this->form_validation->run() == false) {
			$this->load->view('templates/header', $data);
			$this->load->view('templates/sidebar', $data);
			$this->load->view('templates/topbar', $data);
			$this->load->view('data/datausers', $data);
			$this->load->view('templates/footer');
		} else {

			$data = [
				'nama_pelanggan' => $this->input->post('nama_pelanggan'),
				'email' => $this->input->post('email'),
				'password' => $this->input->post('password'),
				'telepon' => $this->input->post('telepon'),
				'alamat' => $this->input->post('alamat'),
			];
			$this->db->insert('pelanggan', $data);
			$this->session->set_flashdata('message', 'New Users Added!');
			redirect('data/managdata/datausers');
		}

	}

	public function hapususers($id) {
		$this->Modeldata_users->hapusDataUsers($id);
		$data['pelanggan'] = $this->Modeldata_users->getDataProdukById($id);
		$this->session->set_flashdata('message', 'Data Telah Berhasil Di Hapus!');
		redirect('data/managdata/datausers');
	}

	public function detailusers($id_pelanggan) {
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$data['dataproduk'] = $this->db->get('data_produk')->result_array();
		$data['data_produk'] = $this->Modelmanag_data->getDataUsersById($id_pelanggan);
		$data['pelanggan'] = $this->db->get('pelanggan')->result_array();

		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('data/detaildatausers', $data);
		$this->load->view('templates/footer');
	}

	public function datauji() {
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$data['datauji'] = $this->Modeldata_uji->getAllUjiData();
		$data['kategori'] = $this->db->get('kategori')->result();

		$this->form_validation->set_rules('nama_datauji', 'Nama_Datauji', 'required|is_unique[data_uji.nama_datauji]', [
			'is_unique' => 'Data Uji Sudah Ada'
		]);
		$this->form_validation->set_rules('id_kate', 'Id_kate', 'required');

		if ($this->form_validation->run() == false) {
			$this->load->view('templates/header', $data);
			$this->load->view('templates/sidebar', $data);
			$this->load->view('templates/topbar', $data);
			$this->load->view('data/dataujidevice', $data);
			$this->load->view('templates/footer');
		} else {
			$this->Modeldata_uji->tambahDataUji();
			$this->session->set_flashdata('message', 'New Data Uji Added!');
			redirect('data/managdata/datauji');
		}

	}

	public function hapusDataUji($id_ujidata) {
		$this->Modeldata_uji->hapusDataUji($id_ujidata);
		$this->session->set_flashdata('message', 'Data Telah Berhasil Di Hapus!');
		redirect('data/managdata/datauji');
	}

	public function getdatauji() {
		echo json_encode($this->Modeldata_uji->getDataUjiById($_POST['id_ujidata']));
	}

	public function getviewdevice() {
		echo json_encode($this->Model_typedevice->getDataTypeDevice($_POST['id_typedevice']));
	}

	public function ubahdatauji() {
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$data['datauji'] = $this->Modeldata_uji->getAllUjiData();
		$data['kategori'] = $this->db->get('kategori')->result();

		$this->form_validation->set_rules('nama_datauji', 'Nama_Datauji', 'required');
		$this->form_validation->set_rules('id_kate', 'Id_kate', 'required');

		if ($this->form_validation->run() == false) {
			$this->load->view('templates/header', $data);
			$this->load->view('templates/sidebar', $data);
			$this->load->view('templates/topbar', $data);
			$this->load->view('data/dataujidevice', $data);
			$this->load->view('templates/footer');
		} else {
			$this->Modeldata_uji->ubahDataUji($_POST);
			$this->session->set_flashdata('message', 'Data Uji updated!');
			redirect('data/managdata/datauji');
		}
	}

	public function typedivace() {
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('data/typedevice', $data);
		$this->load->view('templates/footer');

	}

	public function getdatakategori() {
		echo json_encode($this->Modelkategori_produk->getDataProdukById($_POST['id_kategori']));
	}
	public function getkategoridataajax() {
		echo $this->Modelkategori_produk->read();
	}

	public function getdatalistkategori() {
		echo json_encode($this->Modelkategori_produk->listKategori());
	}

	public function ubahdatakategori() {
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$data['dataproduk'] = $this->db->get('data_produk')->result_array();
		$data['kategori'] = $this->db->get('kategori')->result_array();

		$this->form_validation->set_rules('nama_kategori', 'Nama_Kategori', 'required');
		$this->form_validation->set_rules('keterangan', 'Keterangan', 'required');

		if ($this->form_validation->run() == false) {
			$this->load->view('templates/header', $data);
			$this->load->view('templates/sidebar', $data);
			$this->load->view('templates/topbar', $data);
			$this->load->view('data/kategoriproduk', $data);
			$this->load->view('templates/footer');
		} else {
			$this->Modelkategori_produk->ubahDataKategori($_POST);
			$this->session->set_flashdata('message', 'New kategori updated!');
			redirect('data/managdata/kategoridata');
		}

	}

		public function ubahtypedevice() {
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$data['type_device'] = $this->Model_typedevice->getAllTypeDevice();
		

		$this->form_validation->set_rules('nama_type', 'Nama TypeDevice', 'required');
		$this->form_validation->set_rules('ket_type', 'Keterangan Device', 'required');

		if ($this->form_validation->run() == false) {
			$this->load->view('templates/header', $data);
			$this->load->view('templates/sidebar', $data);
			$this->load->view('templates/topbar', $data);
			$this->load->view('data/typedevice', $data);
			$this->load->view('templates/footer');
		} else {
			$this->Model_typedevice->ubahTypeDevice($_POST);
			$this->session->set_flashdata('message', 'Data Type Device updated!');
			redirect('data/typedevice');
		}
	}

}