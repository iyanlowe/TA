<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Datadevice extends CI_Controller {

	function __construct() {
		parent::__construct();
		$this->load->model('Model_datadevice');
	}

	public function index() {
		$data['typedevice'] = $this->db->get('typedevice')->result();
		$data['kategori'] = $this->db->get('kategori')->result();
		$data['device'] = $this->db->get('device')->result_array();
		$data['datakategoris'] = $this->Model_datadevice->getAllKategoriData();
		$data['datadevice'] = $this->Model_datadevice->getAllDevice();
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

		$this->form_validation->set_rules('kode_device', 'Nomor SN', 'required|is_unique[device.kode_device]', [
			'is_unique' => 'Nomor SN sudah ada'
		]);
		if ($this->form_validation->run() == false) {
			$this->load->view('templates/header', $data);
			$this->load->view('templates/sidebar', $data);
			$this->load->view('templates/topbar', $data);
			$this->load->view('data/device/datadevice', $data);
			$this->load->view('templates/footer');
			$this->session->set_flashdata('message-danger', 'Harap cek kembali inputan anda!');

		}else{
			$this->_tambahdatadevice();
		}
		

	}

	private function _tambahdatadevice() {

		$timekey = round(microtime(true) * 1000);
		$data = [

			'id_typedevice' => $this->input->post('id_typedev'),
			'kode_device' => $this->input->post('kode_device'),
			'timekey' => $timekey,
		];
		$this->db->insert('device', $data);
		$id_device = $this->db->get_where('device', ['timekey' => $timekey])->row()->id_device;
		$datakategori = $this->input->post('id_kate');
		// $namedatauji =$this->input->post('nama_datauji');
		foreach ($datakategori as $dk) {
			$datas = [

				'id_device' => $id_device,
				'id_kategori' => $dk,
				// 'nama_datauji' =>$dt
			];
			$this->db->insert('data_device', $datas);
		}
		$this->session->set_flashdata('message', 'New Data Device Added!');
		redirect(base_url() . 'data/datadevice');

	}

	public function hapusdevice($id_device) {
		$this->Model_datadevice->hapusDevice($id_device);
		$this->session->set_flashdata('message', 'Data Telah Berhasil Di Hapus!');
		redirect('data/datadevice');
	}

	public function getviewdatadevice() {
		echo json_encode($this->Model_datadevice->getDataDevice($_POST['id_device']));
	}

	public function ubahdatadevice()
	{

		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$data['datadevice'] = $this->Model_datadevice->getAllDevice();
		$data['typedevice'] = $this->db->get('typedevice')->result();

		$this->form_validation->set_rules('kode_device', 'Kode Device', 'required');
		$this->form_validation->set_rules('id_typedev', 'Type Device', 'required');
		// $this->form_validation->set_rules('id_kate[]', 'Kategori', 'required');


		if ($this->form_validation->run() == false) {
			$this->load->view('templates/header', $data);
			$this->load->view('templates/sidebar', $data);
			$this->load->view('templates/topbar', $data);
			$this->load->view('data/device/datadevice', $data);
			$this->load->view('templates/footer');
		} else {
			$this->Model_datadevice->ubahDataDevice($_POST);
			$this->session->set_flashdata('message', 'Data Device updated!');
			redirect('data/device/datadevice');
		}
	}
}

