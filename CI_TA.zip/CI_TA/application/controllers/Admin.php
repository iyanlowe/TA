<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('Model_role');
		$this->load->model('User_model');
		
	}

	public function index()
	{
		if ($this->session->userdata('email') == "") {
			redirect('auth');
		}
		$user = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$data = array('title' => 'Halaman Administrator',
					  'user' => $user,
					  'isi'   => 'admin/list');
      	$this->load->view('layout/wrapper', $data, FALSE);
	}
	public function profile()
	{
		if ($this->session->userdata('email') == "") {
			redirect('auth');
		}
		$user = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$role_id =$this->session->userdata('role_id');
		$jabatan = $this->model_role->jabatan($role_id);
		$data = array('title' => 'Profile',
					  'user'  => $user,
					  'jabatan'  => $jabatan,
					  'isi'   => 'admin/profile/list');
      	$this->load->view('layout/wrapper', $data, FALSE);
	}

	public function edit()
	{
		if ($this->session->userdata('email') == "") {
			redirect('auth');
		}
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

		$this->form_validation->set_rules('fname', 'fname', 'required');
		$this->form_validation->set_rules('lname', 'lname', 'required');
		$this->form_validation->set_rules('jenis_kelamin', 'jenis_kelamin', 'required');
		$this->form_validation->set_rules('tanggal_lahir', 'tanggal_lahir', 'required');
		$this->form_validation->set_rules('tempat_lahir', 'tempat_lahir', 'required');

		if ($this->form_validation->run() == false) {
			$data = array('title' => 'Edit Profile',
					  'isi'   => 'admin/profile/list');
      	$this->load->view('layout/wrapper', $data, FALSE);
		} else {
			$this->User_model->ubahProfile();
			redirect('admin/profile');
			$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data telah diubah!<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button></div>');
		}

	}
	public function editPass()
	{
		if ($this->session->userdata('email') == "") {
			redirect('auth');
		}
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

		$this->form_validation->set_rules('fname', 'fname', 'required');
		$this->form_validation->set_rules('lname', 'lname', 'required');
		$this->form_validation->set_rules('jenis_kelamin', 'jenis_kelamin', 'required');
		$this->form_validation->set_rules('tanggal_lahir', 'tanggal_lahir', 'required');
		$this->form_validation->set_rules('tempat_lahir', 'tempat_lahir', 'required');

		if ($this->form_validation->run() == false) {
			$data = array('title' => 'Edit Profile',
					  'user'  =>$this->user_model->listing(),
					  'jabatan'  => $jabatan,
					  'isi'   => 'admin/profile/list');
      	$this->load->view('layout/wrapper', $data, FALSE);
		} else {
			$this->User_model->ubahProfile();
			redirect('admin/profile');
			$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data telah diubah!<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button></div>');
		}

	}

}

/* End of file Coba.php */
/* Location: ./application/controllers/Coba.php */