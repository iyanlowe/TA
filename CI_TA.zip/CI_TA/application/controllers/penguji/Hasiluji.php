<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Hasiluji extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('Modelkategori_produk');
		$this->load->model('Model_hasiluji');
		$this->load->model('Model_datadevice');
	}

	public function index()
	{
		$this->load->view('penguju/templates/header', $data);
		$this->load->view('penguju/templates/sidebar', $data);
		$this->load->view('penguju/templates/topbar', $data);
		$this->load->view('penguju/hasiluji/hasil_uji', $data);
		$this->load->view('penguju/templates/footer');
	}

	public function datahasiluji()
	{
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$data['datadevice'] = $this->Model_datadevice->getAllDevice();
		$data['hasil_uji'] = $this->Model_hasiluji->getAllDataDevice();
		
		$this->load->view('penguji/templates/header', $data);
		$this->load->view('penguji/templates/sidebar', $data);
		$this->load->view('penguji/templates/topbar', $data);
		$this->load->view('penguji/hasiluji/hasil_uji', $data);
		$this->load->view('penguji/templates/footer');

	}

}

	