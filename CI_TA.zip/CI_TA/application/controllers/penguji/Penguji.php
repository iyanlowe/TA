<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Penguji extends CI_Controller 
{
	public function __construct(){
		parent::__construct();
		login_in_penguji();
		$this->load->model('Model_datadevice');
		$this->load->model('Model_pengujian');
		$this->load->model('api_model/Api_modeldatadevice');

		
	}

	public function index()
	{
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

		$this->load->view('penguji/templates/header', $data);
		$this->load->view('penguji/templates/sidebar', $data);
		$this->load->view('penguji/templates/topbar', $data);
		$this->load->view('penguji/penguji_index', $data);
		$this->load->view('penguji/templates/footer');
	}

	public function myprofil()
	{
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

		$this->load->view('penguji/templates/header', $data);
		$this->load->view('penguji/templates/sidebar', $data);
		$this->load->view('penguji/templates/topbar', $data);
		$this->load->view('penguji/profil/myprofil', $data);
		$this->load->view('penguji/templates/footer');
	}

	public function editprofil()
	{
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

		$this->form_validation->set_rules('name', 'Full Name', 'required|trim');

		if ($this->form_validation->run() == false) {
			$this->load->view('penguji/templates/header', $data);
			$this->load->view('penguji/templates/sidebar', $data);
			$this->load->view('penguji/templates/topbar', $data);
			$this->load->view('penguji/profil/editprofil', $data);
			$this->load->view('penguji/templates/footer');
		}else{
			$email = $this->input->post('email');
			$password = $this->input->post('password');
			$name = $this->input->post('name');

			//  jika ada gambar yang diupload
			$upload_image = $_FILES['image']['name'];

			if ($upload_image) {
				$config['allowed_types'] = 'gif|jpg|png';
				$config['max_size']     = '2048';
				$config['upload_path'] = './assets/admin/dist/img/';

				$this->load->library('upload', $config);

				if ($this->upload->do_upload('image'))
				{
					$new_image = $this->upload->data('file_name');
					$this->db->set('image', $new_image);
				}
				else
				{
					echo $this->upload->display_errors();
				}

			}

			$this->db->set('name', $name);
			$this->db->where('email', $email);
			$this->db->where('password', $password);
			$this->db->update('user');

			$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data profil telah di edit! <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button></div>');
			redirect('penguji/penguji');

		}
	}

	public function changespassword()
	{
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();


		$this->form_validation->set_rules('current_password', 'Current_Password', 'required|trim');
		$this->form_validation->set_rules('new_password1', 'New Password', 'required|trim|min_length[8]|matches[new_password2]', [
			'matches' => 'Password dont matches!',
			'min_length' => 'Password too short!'
		]);
		$this->form_validation->set_rules('new_password2', 'Confirm New Password', 'required|trim|matches[new_password1]');

		if ($this->form_validation->run() == false) {

			$this->load->view('penguji/templates/header', $data);
			$this->load->view('penguji/templates/sidebar', $data);
			$this->load->view('penguji/templates/topbar', $data);
			$this->load->view('penguji/profil/changespassword', $data);
			$this->load->view('penguji/templates/footer');
		}else{

			$current_password = $this->input->post('current_password');
			$new_password = $this->input->post('new_password1');
			if(!password_verify($current_password, $data['user']['password'])){
				$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Wrong Current Password <button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
					</button></div>');
				redirect('penguji/penguji/changespassword');
			}else{
				if ($current_password == $new_password) {
					$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">New Password cannot be the same as current password! <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
						</button></div>');
					redirect('penguji/penguji/changespassword');
				}else{
					// pssword sudah benar
					$password_hash = password_hash($new_password, PASSWORD_DEFAULT);
					$this->db->set('password', $password_hash);
					$this->db->where('email', $this->session->userdata('email'));
					$this->db->update('user');

					$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Password Changed! <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
						</button></div>');
					redirect('penguji/penguji/changespassword');
				}
			}
		}
	}

	public function ujidevice()
	{
		$nomorsn = $this->input->post('no_sn');
		$typedevice = $this->input->post('id_typedev');
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$data['typedevice'] = $this->db->get('typedevice')->result();

		$this->form_validation->set_rules('no_sn', 'Nomor SN', 'required|trim');
		$this->form_validation->set_rules('id_typedev', 'typedevice', 'required|trim');


		if ($this->form_validation->run() == false) {
			$this->load->view('penguji/templates/header', $data);
			$this->load->view('penguji/templates/sidebar', $data);
			$this->load->view('penguji/templates/topbar', $data);
			$this->load->view('penguji/ujidevice/ujidevice', $data);
			$this->load->view('penguji/templates/footer');
		}else{
			$this->_uji($nomorsn, $typedevice);
		}
	}

	private function _uji($nomorsn, $typedevice)
	{
		//$nomorsn = $this->input->post('no_sn');

		$device = $this->db->get_where('device', ['kode_device' => $nomorsn])->row_array(); 
		$id_hasiluji = $this->db->get_where('device', ['kode_device' => $nomorsn])->row()->id_device;
		$hasil_uji = $this->db->get_where('hasil_uji', ['id_device' => $id_hasiluji])->row_array();
		//jika SN ada
		if ($device) {
			if ($device['id_typedevice'] == $typedevice) {
				if ($hasil_uji['id_hasilpilih'] !== NULL) {
					$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">
						The device has been tested!<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
						</button></div>');
					redirect('penguji/penguji/ujidevice');

				}else{

					$datadevice = [

						'kode_device' => $device['kode_device'],
						'id_typedevice' => $device['id_typedevice'],
						'timekey' => $device['timekey']
					];
					$this->session->set_userdata($datadevice);
					$this->testuji($nomorsn);

				}
			}else{
				$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">
					Device type does not match the SN number entered, please check again!<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
					</button></div>');
				redirect('penguji/penguji/ujidevice');
			}
			
			
			//redirect('penguji/penguji/testuji');
		}else{
			$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">
				SN number not registered!<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button></div>');
			redirect('penguji/penguji/ujidevice');
		}

	}

	public function testuji($nomorsn)
	{
		//$nomorsn = $this->input->post('no_sn');
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$data['device'] = $this->Model_pengujian->getDatsP();
		$data['dataujisoft'] = $this->db->get_where('data_uji', ['id_kategori' => 13])->result();
		$data['dataujihard'] = $this->db->get_where('data_uji', ['id_kategori' => 14])->result();
		$data['dataujifrim'] = $this->db->get_where('data_uji', ['id_kategori' => 15])->result();
		$data['hasilpilih'] = $this->db->get('pilih_hasil')->result();
		$id_device = $this->db->get_where('device', ['kode_device' => $nomorsn])->row()->id_device;
		
		//echo $nomorsn;

		$data['datakategori'] = $this->Model_datadevice->getAllDataKategoriById($id_device);
		$data['datakategoris'] = $this->Api_modeldatadevice->getAllDataKategoriById($id_device);
		$data['typedevice'] = $this->db->get('typedevice')->result();
		$data['kategori'] = $this->db->get('kategori')->result();

		$this->load->view('penguji/templates/header', $data);
		$this->load->view('penguji/templates/sidebar', $data);
		$this->load->view('penguji/templates/topbar', $data);
		$this->load->view('penguji/ujidevice/testuji', $data);
		$this->load->view('penguji/templates/footer');
	}

	public function hasil_uji()
	{
		$date_created = date('d-m-Y');
		$data = [

			'id_device' => $this->input->post('device_uji'),
			'date_created' => $date_created,
			'id_hasilpilih' => $this->input->post('id_hasilpil'),
			'keterangan' => $this->input->post('ket_uji')
		];
		$this->db->insert('hasil_uji', $data);
		$id_hasil_uji = $this->db->get_where('hasil_uji', ['date_created' => $date_created])->row()->id_hasiluji;
		$pil_datauji = $this->input->post('check_list');
		// $namedatauji =$this->input->post('nama_datauji');
		foreach ($pil_datauji as $du) {
			$datas = [

				'id_hasiluji' => $id_hasil_uji,
				'id_ujidata' => $du,
				// 'nama_datauji' =>$dt
			];
			$this->db->insert('data_hasil_uji', $datas); 
		}
		$this->session->set_flashdata('message', 'New Data Hasil  Uji  has been saved!');
		redirect(base_url() . 'penguji/hasiluji/datahasiluji');

	}

	public function hapushasiluji($id_hasiluji) {
		$this->Model_datadevice->hapusHasilUji($id_hasiluji);
		$this->session->set_flashdata('message', 'Data Telah Berhasil Di Hapus!');
		redirect('penguji/hasiluji/datahasiluji');
	}

	public function checkbox()
	{
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$data['datauji'] = $this->db->get('data_uji')->result();
		$datauji = $this->input->post('check_list');
		$this->load->view('penguji/ujidevice/checkbox',  $data);
	}

	public function insert()
	{
    //Insert second stage details for employer into database.
		$datauji = $this->input->post('check_list');

		foreach ($datauji as $du) {
			$datas = [

				'id_ujidata' => $du,
				
			];
			$this->db->insert('data_hasil_uji', $datas); 
		}
			// $data=array(
			// 	'Specilized_category'=>json_encode(implode(",", $Specilized_category)),
			// );

		redirect('penguji/penguji/checkbox');
	}

	public function blocked()
	{
		$this->load->view('user/error_user');
	}

}
