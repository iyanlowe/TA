<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kerusakan extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('Model_role');
		$this->load->model('User_model');
		$this->load->model('Bencana_model');
		$this->load->model('Kerusakan_model');
		
	}
	public function index()
	{
		if ($this->session->userdata('email') == "") {
			redirect('auth');
		}
		$user = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$kerusakan = $this->Kerusakan_model->listing();
		$jenis_kerusakan = $this->Kerusakan_model->Jenislisting();
		$data = array('title' => 'Management Kerusakan Bencana',
			'user' => $user,
			'kerusakan' => $kerusakan,
			'jenis_kerusakan' => $jenis_kerusakan,
			'isi'   => 'bencana/kerusakan/list');
		$this->load->view('layout/wrapper', $data, FALSE);	
	}
	// management jenis Kerusakan
	public function jenis()
	{
		if ($this->session->userdata('email') == "") {
			redirect('auth');
		}
		$user = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$jenis_kerusakan = $this->Kerusakan_model->Jenislisting();
		$data = array('title' => 'Management Jenis Kerusakan',
			'user' => $user,
			'jenis' => $jenis_kerusakan,
			'isi'   => 'bencana/kerusakan/jenis');
		$this->load->view('layout/wrapper', $data, FALSE);
	}
	public function add_jenis()
	{
		if ($this->session->userdata('email') == "") {
			redirect('auth');
		}
		$this->form_validation->set_rules('jenis', 'Jenis Bencana', 'required|is_unique[jenis_kerusakan.jenis_kerusakan]', [
			'is_unique' => 'Jenis Kerusakan sudah ada!'
		]);
		if ($this->form_validation->run() == false) {
			$user = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
			$jenis_kerusakan = $this->Bencana_model->Jenislisting();
			$data = array('title' => 'Management Jenis Kerusakan',
				'user' => $user,
				'jenis' => $jenis_kerusakan,
				'isi'   => 'bencana/kerusakan/list');
			$this->session->set_flashdata('message',  "<div class='alert alert-danger'>Cek Kembali!</div>");
			$this->load->view('layout/wrapper', $data, FALSE);
		}
      //masuk database
		else {
			$i 			   = $this->input;
			$data = array( 'jenis_kerusakan'		=> $i->post('jenis'),
		);
			$this->Kerusakan_model->addJenis($data);
			$this->session->set_flashdata('message', "<div class='alert alert-success'>Data Berhasil Ditambahkan!");
			redirect('kerusakan/jenis');
		}
	}

	public function edit_jenis()
	{
		// if ($this->session->userdata('email') == "") {
		// 	redirect('auth');
		// }
		// $this->form_validation->set_rules('jenis_bencana', 'Jenis Bencana', 'required|is_unique[jenis_bencana.jenis_bencana]', [
		// 	'is_unique' => 'Jenis Bencana sudah ada!'
		// ]);
		// if ($this->form_validation->run() == false) {
		// 	$user = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		// 	$jenis_bencana = $this->Bencana_model->JenislistingbyId($id_jenis_bencana);
		// 	$data = array('title' => 'Management Jenis Bencana',
		// 		'user' => $user,
		// 		'jenis' => $jenis_bencana,
		// 		'isi'   => 'bencana/edit_j');
		// 	$this->session->set_flashdata('message',  "<div class='alert alert-danger'>Cek Kembali!</div>");
		// 	$this->load->view('layout/wrapper', $data, FALSE);
		// }
      //masuk database

		// else {
		$i 	= $this->input->post();
			$where=array(
				'id_jenis_kerusakan' => $i['id_jenis_kerusakan']

			);
			
			
			$data = array( 
							'jenis_kerusakan'		=>$i['jenis'],
			);
			$this->Kerusakan_model->editJenis($where,$data);
			$this->session->set_flashdata('message', "<div class='alert alert-success'>Data Berhasil Diubah!");
			redirect('kerusakan/jenis');
		//}
	}

	public function hapus_jenis($id_jenis_kerusakan) {
		$this->Kerusakan_model->hapusJenisKerusakan($id_jenis_kerusakan);
		$this->session->set_flashdata('message', "<div class='alert alert-success'>Data Berhasil Di Hapus!");
		redirect('kerusakan/jenis');
	}
	// end management jenis

	//management Kerusakan
	public function add_bencana()
	{
		if ($this->session->userdata('email') == "") {
			redirect('auth');
		}
		$this->form_validation->set_rules('nama_bencana', 'Nama Bencana', 'required|is_unique[bencana.nama_bencana]', [
			'is_unique' => 'Nama Bencana sudah ada!'
		]);
		if ($this->form_validation->run() == false) {
			$user = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
			$jenis_bencana = $this->Bencana_model->Jenislisting();
			$data = array('title' => 'Management Bencana',
				'user' => $user,
				'jenis' => $jenis_bencana,
				'isi'   => 'bencana/list');
			$this->session->set_flashdata('message',  "<div class='alert alert-danger'>Cek Kembali!</div>");
			$this->load->view('layout/wrapper', $data, FALSE);
			
		}
      //masuk database
		else {
			$i 			   = $this->input;
			$data = array( 'id_jenis_bencana'	=> $i->post('id_jenis_bencana'),
				'nama_bencana'		=> $i->post('nama_bencana'),
			); 
			$this->Bencana_model->addBencana($data);
			$this->session->set_flashdata('message', "<div class='alert alert-success'>Data Berhasil Ditambahkan!</div>");
			redirect('bencana');
		}
	}

	public function edit_bencana()
	{
		// if ($this->session->userdata('email') == "") {
		// 	redirect('auth');
		// }
		
		// if ($this->form_validation->run() == false) {
		// 	$user = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		// 	$bencana = $this->Bencana_model->BencanalistingbyId($id_bencana);
		// 	$jenis_bencana = $this->Bencana_model->jenislisting();
		// 	$data = array('title' => 'Management Data Bencana',
		// 		'user' => $user,
		// 		'bencana' => $bencana,
		// 		'jenis_bencana' => $jenis_bencana,
		// 		'isi'   => 'bencana/list');
		// 	$this->session->set_flashdata('message',  "<div class='alert alert-danger'>Cek Kembali!</div>");
		// 	$this->load->view('layout/wrapper', $data, FALSE);
		// }
  //     //masuk database
		// else {

			$post=$this->input->post();

			$where=array(
				'id_bencana' => $post['id_bencana']

			);

			$data=array(	
				'id_jenis_bencana' => $post['id_jenis_bencana'],
				'nama_bencana' => $post['nama_bencana']

			);
			$this->Bencana_model->editBencana($where,$data);
			$this->session->set_flashdata('message', "<div class='alert alert-success'>Data Berhasil Diubah!");
			redirect('bencana','refresh');
		// }
	}

	public function hapus_bencana($id_bencana) {
		$this->Bencana_model->hapusBencana($id_bencana);
		$this->session->set_flashdata('message', "<div class='alert alert-success'>Data Berhasil Di Hapus!</div>");
		redirect('bencana');
	}
	public function laporan()
	{
		if ($this->session->userdata('email') == "") {
			redirect('auth');
		}
		$user = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$petugas = $this->User_model->listing();
		$data = array('title' => 'Laporan Bencana',
			'user' => $user,
			'petugas' => $petugas,
			'isi'   => 'bencana/laporan/list');
		$this->load->view('layout/wrapper', $data, FALSE);
	}
}

/* End of file Kerusakan.php */
/* Location: ./application/controllers/Kerusakan.php */