<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PetugasA extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('Model_role');
		$this->load->model('User_model');
		
	}

	public function index()
	{
		if ($this->session->userdata('email') == "") {
			redirect('auth');
		}
		$user = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$petugas = $this->User_model->listing();
		$data = array('title' => 'Management Data Petugas A',
					  'user' => $user,
					  'petugas' => $petugas,
					  'isi'   => 'admin/petugas/list');
      	$this->load->view('layout/wrapper', $data, FALSE);
	}

	//Edit petugasa
	public function edit($id_user)
	{
		if ($this->session->userdata('email') == "") {
			redirect('auth');
		}
		$petugas = $this->User_model->detail($id_user);
		//Validasi Input
		$valid = $this->form_validation;

		$valid->set_rules('role_id', 'Jabatan', 'required',
						array('required' 	=> '%s Harus Di Isi'
						 ));
		$valid->set_rules('active_id', 'Status Akun', 'required',
						array('required' 	=> '%s Harus Di Isi'
						 ));

		if ($valid->run()===FALSE) {
			//end Validasi
		
		$data = array  ('title' => 'Edit Kategori Produk',
						'petugas'	=> $petugas,
						'isi'	=> 'admin/petugas/list'
					);
		$this->load->view('admin/layout/wrapper', $data, FALSE);
		//Masuk Database
		}else {
			$i 			   = $this->input;
			$data = array('id_user'			=> $id_user,
						  'active_id'		=>$i->post('status'),
						  'role_id'		=> $i->post('jabatan'),
						);
			$this->User_model->edit($data);
			$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data telah diubah!<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button></div>');
			redirect(base_url('petugas/petugasa'),'refresh');
		}
		//end Masuk Database
	}

	//Delete Kategori
	public function delete($data)
	{
		if ($this->session->userdata('email') == "") {
			redirect('auth');
		}
		$this->db->where('id_user',$data['id_user']);
		$this->db->delete('user',$data);
	}

}

/* End of file PetugasA.php */
/* Location: ./application/controllers/petugas/Petugas.php */