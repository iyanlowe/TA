<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PetugasB extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('Model_role');
		$this->load->model('User_model');
		
	}

	public function index()
	{
		if ($this->session->userdata('email') == "") {
			redirect('auth');
		}
		$user = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		$petugas = $this->User_model->listing();
		$data = array('title' => 'Management Data Petugas B',
					  'user' => $user,
					  'petugas' => $petugas,
					  'isi'   => 'admin/petugas/list2');
      	$this->load->view('layout/wrapper', $data, FALSE);
	}

}

/* End of file PetugasB.php */
/* Location: ./application/controllers/petugas/PetugasB.php */