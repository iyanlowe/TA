<?php

namespace Box\Spout\Reader\Exception;

use Box\Spout\Common\Exception\SpoutException;

/**
 * Class ReaderException
 *
 * @abstract
 */
abstract class ReaderException extends SpoutException
{
}
