<!-- Page wrapper  -->
<!-- ============================================================== -->
<div class="page-wrapper">
    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="page-breadcrumb">
        <div class="row">
            <div class="col-7 align-self-center">
                <h4 class="page-title text-truncate text-dark font-weight-medium mb-1">Form <?= $title; ?></h4>
                <div class="d-flex align-items-center">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb m-0 p-0">
                            <li class="breadcrumb-item"><a href="<?= base_url('admin') ?>" class="text-muted">Dashboard</a></li>
                            <li class="breadcrumb-item text-muted active" aria-current="page"><?= $title; ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
            <div class="col-5 align-self-center">
                <div class="customize-input float-right">
                    <select class="custom-select custom-select-set form-control bg-white border-0 custom-shadow custom-radius">
                        <option selected>Aug 19</option>
                        <option value="1">July 19</option>
                        <option value="2">Jun 19</option>
                    </select>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Container fluid  -->
    <!-- ============================================================== -->
    <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- Start Page Content -->
        <!-- ============================================================== -->
    
        <div class="row">
            <div class="col-4">
                <div class="card-group text-center">
                    <div class="card-body">
                        <div class="form-body">
                            <div class="col-md-12 text-center">
                                <div class="row">
                                    <form class="mt-3">
                                        <div class="form-group text-center">
                                            
                                            <img src="<?= base_url().'assets/template/images/users/'.$user['image'];?>" posisition="center" alt="image" class="rounded-circle"width="200" height="200" > 
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <h5 class="text-dark mb-0 font-16 font-weight-medium"><?= $user['fname'] ;?>  <?= $user['lname'] ;?></h5>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                             <span class="text-muted font-14"><?= $jabatan['jabatan'] ;?></span>
                                         </div>
                                     </div>
                                     <i class="fa fa-facebook-square" style="font-size:40px"></i>
                                     <i class="fa fa-instagram" style="font-size:40px"></i>
                                     <i class="fa fa-twitter-square" style="font-size:40px"></i>
                                     <fieldset class="form-group">
                                        <input type="file" class="form-control-file" id="gambar" name="gambar" placeholder="Upload Gambar Baru" >
                                    </fieldset>
                                </form>
                            </div> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">

                    <h4 class="card-title mb-3"> My Profile</h4>

                    <ul class="nav nav-tabs nav-bordered mb-3">
                        <li class="nav-item">
                            <a href="#home-b1" data-toggle="tab" aria-expanded="false" class="nav-link active">
                                <i class="mdi mdi-home-variant d-lg-none d-block mr-1"></i>
                                <span class="d-none d-lg-block">Profile</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#profile-b1" data-toggle="tab" aria-expanded="true"
                            class="nav-link">
                            <i class="mdi mdi-account-circle d-lg-none d-block mr-1"></i>
                            <span class="d-none d-lg-block">Account</span>
                        </a>
                    </li>
                    
                </ul>

                <div class="tab-content">
                    <div class="tab-pane show active" id="home-b1">
                        <div class="form-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>First Name</label>
                                        <input type="text" class="form-control" value="<?= $user['fname'] ;?>" readonly>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Last Name</label>
                                        <input type="text" class="form-control" value="<?= $user['lname'] ;?>" readonly>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Place Of Birth</label>
                                        <input type="text" class="form-control" placeholder="" readonly="" value="<?php if ($user['tempat_lahir'] == "" ) {
                                          echo "Data Tidak Ada";
                                          }else
                                          { echo $user['tempat_lahir'];
                                      }?>">
                                  </div>
                              </div>

                              <div class="col-md-6">
                                <div class="form-group">
                                    <label>Birthday</label>
                                    <input type="text" class="form-control" placeholder="" readonly="" value="<?php if ($user['tanggal_lahir'] != "" ) {
                                      echo "Data Tidak Ada";
                                      }else
                                      { echo $user['tanggal_lahir'];
                                  }?>">
                              </div>
                          </div>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Jabatan</label>
                                <input type="text" class="form-control" readonly value="<?= $jabatan['jabatan'] ;?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Status</label>
                                <input type="text" class="form-control" readonly value="<?php if ($jabatan['active_id'] == 1) {
                                  echo "Aktif";
                                  }else
                                  { echo "Tidak Aktif";
                              }?>">
                          </div>
                      </div>
                  </div>
                  <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                            <label>Gender</label>
                            <input type="text" class="form-control" readonly value="<?php if ($user['jenis_kelamin'] != "") {
                              echo $user['jenis_kelamin'];
                              }else
                              { echo "Data Tidak Ada ";
                          }?>">
                      </div>
                  </div>
              </div>
              <div class="col-lg-12 text-right mt-3">
                <button type="button" data-toggle="modal" data-target="#edit_profile" class=" btn btn-success">Edit Profile</button>
            </div>
        </div>
    </div>
    <div class="tab-pane " id="profile-b1">
        <div class="form-body">
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Email</label>
                        <input type="text" class="form-control" placeholder="" value="<?= $user['email'] ;?>" readonly>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" class="form-control" value="<?= $user['password'] ;?>" readonly>
                    </div>
                </div>
            </div>
            <div class="col-lg-12 text-right mt-3">
                <button type="button" data-toggle="modal" data-target="#edit_password" class="btn btn-success">Edit Account</button>
            </div>
        </div>
    </div>

</div> <!-- end card-body-->
</div> <!-- end card-->
</div> <!-- end col -->
</div>



<!--  modal content -->

<div id="edit_profile" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-body">
                <div class="mt-2 mb-4">
                    <b><h4 class="card-title mb-3">Edit Profile</h4></b>
                    <?= $this->session->flashdata('message'); ?>
                </div>

                <form class="pl-3 pr-3" action="<?= base_url('admin/edit'); ?>" method="post">
                    <div class="row">
                        <div class="col-md-6">
                            <input type="hidden" id="id_profil" name="id_profil">
                            <div class="form-group">
                                <label for="emailaddress">First Name</label>
                                <input class="form-control" type="text" name="fname" id="fname"
                                required="" placeholder="Input First Name" value="<?= $user['fname'];?>">
                                <?= form_error('fname','<small class="text-danger pl-3">', '</small>');?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="emailaddress">Last Name</label>
                                <input class="form-control" type="text" name="lname" id="lname"
                                required="" placeholder="Input Last Name" value="<?= $user['lname'];?>">
                                <?= form_error('lname','<small class="text-danger pl-3">', '</small>');?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="emailaddress">Place Of Birth</label>
                                <input class="form-control" type="text" name="tempat_lahir" id="tempat_lahir"
                                required="" placeholder="Input Place Of Birthday" value="<?= $user['tempat_lahir'];?>">
                                <?= form_error('tempat_lahir','<small class="text-danger pl-3">', '</small>');?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="emailaddress">Birth</label>
                                <input class="form-control" type="date" name="tanggal_lahir" id="tanggal_lahir"
                                required="" placeholder="Input Birthday" value="<?= $user['tanggal_lahir'];?>">
                                <?= form_error('tanggal_lahir','<small class="text-danger pl-3">', '</small>');?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="emailaddress">Gender</label>
                        <select class="form-control" name="jenis_kelamin" id="jenis_kelamin" required>
                            <option value="L">Laki-Laki</option>
                            <option value="P">Perempuan</option>
                        </select>
                    </div>
                    <div class="form-group text-right">
                        <button class="btn btn-primary" type="submit">Submit</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Back</button>
                    </div>
                </form>
            </div>

        </div>
    </div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<!--  modal content -->

<div id="edit_password" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-body">
                <div class="mt-2 mb-4">
                    <b><h4 class="card-title mb-3">Edit Password</h4></b>
                    <?= $this->session->flashdata('message'); ?>
                </div>

                <form class="pl-3 pr-3" action="<?= base_url('admin/editpass'); ?>" method="post">
                    <div class="row">
                        <div class="col-md-6">
                            <input type="hidden" id="id_profil" name="id_profil">
                            <div class="form-group">
                                <label>Password Lama</label>
                                <input class="form-control" type="text" name="fname" id="fname"
                                required="" placeholder="Input Password Lama">
                                <?= form_error('fname','<small class="text-danger pl-3">', '</small>');?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>New Password</label>
                                <input class="form-control" type="password" name="password" id="password"
                                required="" placeholder="Input New Password">
                                <?= form_error('password','<small class="text-danger pl-3">', '</small>');?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Confirm Password</label>
                                <input class="form-control" type="text" name="password2" id="password"
                                required="" placeholder="Confirmasi Password">
                                <?= form_error('password2','<small class="text-danger pl-3">', '</small>');?>
                            </div>
                        </div>
                    </div>
                    
                    
                    <div class="form-group text-right">
                        <button class="btn btn-primary" type="submit">Submit</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Back</button>
                    </div>

                </form>
            </div>

        </div>
    </div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->
<!-- ============================================================== -->
                <!-- End PAge Content -->