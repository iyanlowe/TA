<!-- Page wrapper  -->
<!-- ============================================================== -->
<div class="page-wrapper">
  <!-- ============================================================== -->
  <!-- Bread crumb and right sidebar toggle -->
  <!-- ============================================================== -->
  <div class="page-breadcrumb">
    <div class="row">
      <div class="col-7 align-self-center">
        <h4 class="page-title text-truncate text-dark font-weight-medium mb-1">Management Petugas</h4>
        <div class="d-flex align-items-center">
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb m-0 p-0">
              <li class="breadcrumb-item"><a href="<?php echo base_url('admin') ?>" class="text-muted">Home</a></li>
              <li class="breadcrumb-item text-muted active" aria-current="page">Petugas 1</li>
            </ol>
          </nav>
        </div>
      </div>
      <div class="col-5 align-self-center">
        <div class="customize-input float-right">
          <select class="custom-select custom-select-set form-control bg-white border-0 custom-shadow custom-radius">
            <option selected>Aug 19</option>
            <option value="1">July 19</option>
            <option value="2">Jun 19</option>
          </select>
        </div>
      </div>
    </div>
  </div>
  <!-- ============================================================== -->
  <!-- End Bread crumb and right sidebar toggle -->
  <!-- ============================================================== -->
  <!-- ============================================================== -->
  <!-- Container fluid  -->
  <!-- ============================================================== -->
  <div class="container-fluid">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <!-- multi-column ordering -->
    <div class="row">
      <div class="col-12 ">
        <div class="card ">
          <div class="card-body ">
            <h4 class="card-title"><?= $title; ?></h4>
            <div class="flash-data" data-flashdata="<?=$this->session->flashdata('message');?>"></div>
            <div class="">
              <table id="multi_col_order"
              class="table table-striped table-bordered display no-wrap" style="width:100%">
              <thead>
                <tr>
                 <th>No</th>
                 <th>Full Name</th>
                 <th>Position</th>
                 <th>Email</th>
                 <th>Gender</th>
                 <th>Action</th>
               </tr>
             </thead>
             <tbody>
              <?php $no = 1;foreach ($petugas as $user) {?>
                <?php if ($user->jabatan == "Petugas 1"){ ?>
                  <tr>
                    <td><?php echo $no; ?></td>
                    <td><?php echo $user->fname; ?> <?php echo $user->lname; ?></td>
                    <td><?php echo $user->jabatan; ?></td>
                    <td><?php echo $user->email; ?></td>

                    <td><?php echo $user->jenis_kelamin ?></td>
                    <td><button type="button" data-toggle="modal" class = "btn btn-rounded  btn-info btn-xs" data-target="#modal-viewdevice" data-id_device="<?=$user->id_user?>"><i class="fa fa-eye"></i>Detail</button>

                      <a href="" data-toggle="modal" class = "btn btn-rounded  btn-warning btn-xs" data-target="#modal-edit" data-id_device="<?=$user->id_user?>"><i class="fa fa-edit"></i>Edit</a>
                      <a href="<?=base_url();?>petugas/petugasA/delete/<?= $user->id_user;?>" class = "btn btn-rounded  btn-danger btn-xs" onclick="return confirm('yakin?');"><i class="fa fa-trash-o"></i>Delete</a></td>
                    </tr>
                    <?php $no++;  }} ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- ============================================================== -->
      <!-- End PAge Content -->
      <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Container fluid  -->

    <div id="modal-viewdevice" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">

          <div class="modal-body">
            <div class="text-center mt-2 mb-4">
              <a href="index.html" class="text-success">
                <span><img class="mr-2" src="<?= base_url() ?>/assets/template//images/logo-icon.png"
                  alt="" height="18"><img
                  src="<?= base_url() ?>/assets/template//images/logo-text.png" alt=""
                  height="18"></span>
                </a>
                <?= $this->session->flashdata('message'); ?>
              </div>

              <form class="pl-3 pr-3" action="" method="post">
                <input type="hidden" name="id_device" id="id_device">

                <div class="row">
                  <div class="col-md-12">
                    <div class="table-responsive">
                      <p><i>Management Account:</i></p>
                      <table class="table table-striped table-bordered">
                       <tbody>
                        <tr>
                          <th>Full Name</th>
                          <td><?php echo $user->fname;?> <?php echo $user->lname;?></td>
                        </tr>
                        <tr>
                          <th>Email</th>
                          <td><?php echo $user->email;?></td>
                        </tr>
                        <tr>
                          <th>Tempat,Tanggal Lahir</th>
                          <td><?php echo $user->tempat_lahir;?><?php echo $user->tanggal_lahir;?></td>
                        </tr>
                        <tr>
                          <th>Gender</th>
                          <td><?php echo $user->jenis_kelamin;?></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              <div class="form-group text-right">

                <button type="button" class="btn btn-secondary" data-dismiss="modal">Back</button>
              </div>

            </form>
          </div>
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->

    <div id="modal-edit" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">

          <div class="modal-body">
            <div class="text-center mt-2 mb-4">
              <a href="index.html" class="text-success">
                <span><img class="mr-2" src="<?= base_url() ?>/assets/template//images/logo-icon.png"
                  alt="" height="18"><img
                  src="<?= base_url() ?>/assets/template//images/logo-text.png" alt=""
                  height="18"></span>
                </a>
                <?= $this->session->flashdata('message'); ?>
              </div>

              <form class="pl-3 pr-3" action="<?=base_url('petugas/petugasA/'. $user->id_user);?>" method="post">
                <input type="hidden" name="id_device" id="id_device">

                <div class="row">
                  <div class="col-md-12">
                    <div class="table-responsive">
                      <p><i>Management Account:</i></p>
                      <table class="table table-striped table-bordered">
                       <tbody>
                        <tr>
                          <th>Posisition</th>
                          <td>
                              <select id="jabatan" name="jabatan" class="form-control">
                                <option selected>Choose...</option>
                                <option value="2">Petugas 1</option>
                                <option value="3">Petugas 2</option>
                                <option value="4">Petugas 3</option>
                              </select>
                          </td>
                        </tr>
                        <tr>
                          <th>Status Akun</th>
                          <td> <select id="status" name="status" class="form-control">
                                <option selected>Choose...</option>
                                <option value="1">Aktive</option>
                                <option value="2">Tidak Aktive</option>
                              </select></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              <div class="form-group text-right">
                <button type="submit" class="btn btn-info">Edit</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
              </div>

            </form>

          </div>
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
        </div><!-- /.modal -->