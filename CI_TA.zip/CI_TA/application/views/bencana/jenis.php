<!-- Page wrapper  --> 
<!-- ============================================================== -->
<div class="page-wrapper">
    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="page-breadcrumb">
        <div class="row">
            <div class="col-7 align-self-center">
                <h4 class="page-title text-truncate text-dark font-weight-medium mb-1">Management Bencana</h4>
                <div class="flash-data" data-flashdata="<?= $this->session->flashdata('message');?>"></div>

                <div class="d-flex align-items-center">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb m-0 p-0">
                            <li class="breadcrumb-item"><a href="<?php echo base_url('admin') ?>" class="text-muted">Home</a></li>
                            <li class="breadcrumb-item text-muted active" aria-current="page"><?= $title; ?></li>
                        </ol>
                    </nav>
                </div>
                 <!-- <?= $this->session->flashdata('message');?> -->
            </div>
            <div class="col-5 align-self-center">
                <div class="customize-input float-right">
                    <button type="button" data-toggle="modal" data-target="#add_jenis" class="btn  btn-rounded btn-primary mb-3 mt-5"><i class="fa fa-plus-square"></i> Add New</button>
                </div>
            </div>
            <?= $this->session->flashdata('message');?>
        </div>
    </div>   
    <!-- multi-column ordering -->
    <div class="row">
        <div class="table-responsive">
            <div class="table-responsive">
                <div class="card-body ">
                    <div class="table-responsive">
                          <div class="flash-data" data-flashdata="<?= $this->session->flashdata('message');?>"></div>
                       <table id="zero_config" class="table table-striped table-bordered no-wrap">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Jenis Bencana</th>
                                    <th style="text-align:center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                             <?php $no = 1;foreach ($jenis as $jb) {?>
                                <tr>
                                    <td><?= $no; ?></td>
                                    <td><?= $jb['jenis_bencana']; ?></td>
                                    <td style="text-align:center">
                                        <button type="button" data-toggle="modal" data-target="#edit<?= $jb['id_jenis_bencana'];?>" class="btn  btn-rounded btn-info"><i class="fa fa-edit"></i> Edit</button>
                                        <a  href="<?= base_url('bencana/hapus_jenis/'.$jb['id_jenis_bencana']) ?>" class="btn btn-rounded btn-danger tombol-hapus"><i class="fa fa-trash-o"></i> Delete</a>
                                    </td>
                                </tr>
                                <?php $no++;}?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End PAge Content -->


    <!-- modal content -->
    <div id="add_jenis" class="modal fade" tabindex="-1" role="dialog"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-body">
                <div class="text-center mt-2 mb-4">
                    <a href="#" class="text-success">
                        <span><img class="mr-2" src="<?= base_url() ?>/assets/template/images/coba.png"
                            alt="" height="18"><img
                            src="<?= base_url() ?>/assets/template//images/logo-text.png" alt=""
                            height="18"></span>
                        </a>
                    </div>

                    <form class="pl-3 pr-3" action="<?= base_url('bencana/add_jenis'); ?>" method="post">


                        <div class="form-group">
                            <label for="emailaddress">Jenis Bencana</label>
                            <input class="form-control" type="text" name="jenis" id="jenis"
                            required="" placeholder="Input Jenis Bencana" value="<?= set_value('jenis');?>">
                            <?= form_error('jenis','<small class="text-danger pl-3">', '</small>');?>
                        </div>
                        <div class="form-group text-center">
                            <button class="btn btn-primary" type="submit" name="ubah">Submit</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Back</button>
                        </div>

                    </form>

                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->

    <?php $no = 1;foreach ($jenis as $b) {?>
<div id="edit<?= $b['id_jenis_bencana'] ?>" class="modal fade" tabindex="-1" role="dialog"
   aria-hidden="true">
   <div class="modal-dialog">
    <div class="modal-content">

        <div class="modal-body">
            <div class="text-center mt-2 mb-4">
                <a href="#" class="text-success">
                    <span><img class="mr-2" src="<?= base_url() ?>/assets/template/images/coba.png"
                        alt="" height="18"><img
                        src="<?= base_url() ?>/assets/template/images/logo-text.png" alt=""
                        height="18"></span>
                    </a>
                </div>

                <form class="pl-3 pr-3" action="<?= base_url('bencana/edit_jenis'); ?>" method="post" enctype="multipart/form-data" role="form">
                   <div class="form-group">
                            <label for="emailaddress">Jenis Bencana</label>
                            <input class="form-control" type="text" name="jenis" id="jenis"
                            required="" placeholder="Input Jenis Bencana" value="<?= $b['jenis_bencana'];?>">
                            <?= form_error('jenis','<small class="text-danger pl-3">', '</small>');?>
                        </div>
                <div class="form-group text-center">
                   <input type="hidden" id="id_jenis_bencana" name="id_jenis_bencana" value="<?= $b['id_jenis_bencana'];?>">
                   <button class="btn btn-primary" type="submit">Submit</button>
                   <button type="button" class="btn btn-secondary" data-dismiss="modal">Back</button>
               </div>
           </form>

       </div>
   </div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<?php } ?>
