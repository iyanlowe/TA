<?php

	//Memanggil data isi content dari controller isi
	if ($isi) {
		$this->load->view($isi);
	}
  ?>