<!-- ============================================================== -->
<!-- Left Sidebar - style you can find in sidebar.scss  -->
<!-- ============================================================== -->
<aside class="left-sidebar" data-sidebarbg="skin6">
  <!-- Sidebar scroll-->
  <div class="scroll-sidebar" data-sidebarbg="skin6">
    <!-- Sidebar navigation-->
    <nav class="sidebar-nav">
      <ul id="sidebarnav">
        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="<?php echo base_url('admin') ?>"
          aria-expanded="false"><i data-feather="home" class="feather-icon"></i><span
          class="hide-menu">Dashboard</span></a></li>
          <li class="list-divider"></li>
          <li class="nav-small-cap"><span class="hide-menu">Main Menu</span></li>

          <li class="sidebar-item"> <a class="sidebar-link" href="<?php echo base_url('bencana/laporan') ?>"
            aria-expanded="false"><i data-feather="tag" class="feather-icon"></i><span
            class="hide-menu">Laporan Bencana
          </span></a>
        </li>
        <li class="list-divider"></li>
        <li class="nav-small-cap"><span class="hide-menu">Menu Management</span></li>
        <li class="sidebar-item"> <a class="sidebar-link has-arrow" href="javascript:void(0)"
          aria-expanded="false"><i data-feather="file-text" class="feather-icon"></i><span
          class="hide-menu">Bencana </span></a>
          <ul aria-expanded="false" class="collapse  first-level base-level-line">
            <li class="sidebar-item"><a href="<?= base_url('bencana/jenis') ?>" class="sidebar-link"><span
              class="hide-menu">Jenis Bencana
            </span></a>
          </li>
          <li class="sidebar-item"><a href="<?= base_url('bencana')?>" class="sidebar-link"><span
            class="hide-menu">Nama Bencana
          </span></a>
        </li>
      </li>
    </ul>
  </li>
  <li class="sidebar-item"> <a class="sidebar-link has-arrow" href="javascript:void(0)"
    aria-expanded="false"><i data-feather="grid" class="feather-icon"></i><span
    class="hide-menu">Petugas</span></a>
    <ul aria-expanded="false" class="collapse  first-level base-level-line">
      <li class="sidebar-item"><a href="<?= base_url('petugas/petugasA') ?>" class="sidebar-link"><span
        class="hide-menu">Petugas 1
      </span></a>
    </li>
    <li class="sidebar-item"><a href="<?= base_url('petugas/petugasB') ?>" class="sidebar-link"><span
      class="hide-menu">Petugas 2
    </span></a>
  </li>
  <li class="sidebar-item"><a href="<?= base_url('petugas/petugasC') ?>" class="sidebar-link"><span
    class="hide-menu">Petugas 3
  </span></a>
</li>
</ul>
</li>
<li class="sidebar-item"> <a class="sidebar-link has-arrow" href="javascript:void(0)"
    aria-expanded="false"><i data-feather="grid" class="feather-icon"></i><span
    class="hide-menu">Kerusakan</span></a>
    <ul aria-expanded="false" class="collapse  first-level base-level-line">
      <li class="sidebar-item"><a href="<?= base_url('kerusakan/jenis') ?>" class="sidebar-link"><span
        class="hide-menu">Jenis Kerusakan
      </span></a>
    </li>
</ul>
</li>
<li class="sidebar-item"> <a class="sidebar-link" href="<?= base_url('cuaca') ?>" aria-expanded="false">
  <i data-feather="tag" class="feather-icon"></i>
  <span class="hide-menu">Cuaca
  </span></a>
</li>
<li class="list-divider"></li>
<li class="nav-small-cap"><span class="hide-menu">Konfigurasi</span></li>

<li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="<?= base_url('konfigurasi') ?>"
  aria-expanded="false"><i data-feather="lock" class="feather-icon"></i><span
  class="hide-menu">Logo Website
</span></a>
</li>
<li class="sidebar-item"> <a class="sidebar-link sidebar-link"
  href="<?= base_url('konfigurasi/website') ?>" aria-expanded="false"><i data-feather="lock"
  class="feather-icon"></i><span class="hide-menu">Website
  </span></a>
</li>
<li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="<?= base_url('auth/logout') ?>"
  aria-expanded="false"><i data-feather="log-out" class="feather-icon"></i><span
  class="hide-menu">Logout</span></a></li>
</ul>
</nav>
<!-- End Sidebar navigation -->
</div>
<!-- End Sidebar scroll-->
</aside>
<!-- ============================================================== -->
<!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->