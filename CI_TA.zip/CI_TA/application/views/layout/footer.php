<!-- footer -->
<!-- ============================================================== -->
<footer class="footer text-center text-muted">
  All Rights Reserved by Adminmart. Designed and Developed by <a
  href="https://wrappixel.com">WrapPixel</a>.
</footer>

<!-- ============================================================== -->
<!-- End footer -->
<!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Page wrapper  -->
<!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Wrapper -->
<!-- ============================================================== -->
<!-- End Wrapper -->
<!-- ============================================================== -->
<!-- All Jquery -->
<!-- ============================================================== -->
 <script src="../dist/js/pages/datatable/datatable-basic.init.js"></script>
<script src="<?= base_url() ?>/assets/template/libs/jquery/dist/jquery.min.js"></script>
<script src="<?= base_url() ?>/assets/template/libs/popper.js/dist/umd/popper.min.js"></script>
<script src="<?= base_url() ?>/assets/template/libs/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- apps -->
<script src="<?= base_url() ?>/assets/template/dist/js/app-style-switcher.js"></script>
<script src="<?= base_url() ?>/assets/template/dist/js/feather.min.js"></script>
<script src="<?= base_url() ?>/assets/template/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
<script src="<?= base_url() ?>/assets/template/dist/js/sidebarmenu.js"></script>
<!--Custom JavaScript -->
<script src="<?= base_url() ?>/assets/template/dist/js/custom.min.js"></script>
<script src="<?= base_url() ?>/assets/template/extra-libs/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>/assets/template/dist/js/pages/datatable/datatable-basic.init.js"></script>
<script src="<?= base_url() ?>/assets/sweetalert/myscript.js"></script>
<script src="<?= base_url() ?>/assets/sweetalert/sweetalert2.min.js"></script>
<script>
    $(document).ready(function() {
        $('#tags_1').tagsinput({
            width:'auto',
        });
        $("input").val()
    });
</script>
</body>


</html>