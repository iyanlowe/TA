<?php
	//Proteksi halaman petugas,dengan fungsi cek login yang ada di simple login
	//$this->simple_login->_login();
	//Gabungkan semua bagian layout menjadi satu
require_once('header.php');
require_once('nav.php');
require_once('sidebar.php');
require_once('content.php');
require_once('footer.php');
  ?>