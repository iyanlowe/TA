 <div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Edit Kategori : 
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="#">Examples</a></li>
      <li class="active">Edit kategori</li>
    </ol>
  </section>

  <!-- Main content -->

  <section class="content">
    <div class="box">

      <div class="btn-group pull-right">
        <a href="<?=base_url('data/managdata/kategoridata');?>" title="Kembali" class = "btn-info btn-sm">
          <i class="fa fa-backward"></i>Kembali
        </a>
      </div>
      <div class="box-body">
       <div class="flash-data" data-flashdata="<?=$this->session->flashdata('message');?>"></div>
       <form action="" method="post">
        <input type="hidden" name="id_kategori" value="<?= $data_kategori['id_kategori'];?>" >

        <!-- Default box -->
        <div class="form-group row">
          <label class="col-sm-2 col-form-label">Nama Kategori</label>
          <div class="col-sm-7">
            <input type="text" name="nama_kategori" id="nama_kategori" class="form-control" value="<?= $data_kategori['nama_kategori'];?>">
          </div>
        </div>

        <div class="form-group row">
          <label class="col-sm-2 col-form-label">Keterangan</label>
          <div class="col-sm-7">
            <input type="text" name="keterangan" id="keterangan" class="form-control" value="<?= $data_kategori['keterangan'];?>">
          </div>
        </div>
        <div class="form-group">
          <label  class="col-md-2 control-label"></label>
          <div class="col-md-5">
            <button class="bnt btn-success btn-lg" name="edit" type="submit">
              <i class="fa fa-save"></i>Edit Data
            </button>
          </div>
        </div>

      </form>


    </div>
  </div>
</section>

<!-- /.content -->
</div>
<!-- /.content-wrapper -->
