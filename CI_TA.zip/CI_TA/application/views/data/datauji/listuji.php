<div class="content-wrapper">
  <!-- Content Header (Page header) -->

  <section class="content-header">
    <h1>
      List Data Uji
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">List Data Uji</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">

    <!-- Default box -->
    <div class="box">
      <div class="box-body">
        <?=$this->session->flashdata('message');?>

        <table id="tbldata" class="table table-bordered table-striped">
          <a href="" class="btn btn-primary mb-3 mt-5" data-toggle="modal" data-target="#data_listuji"><i class="fa fa-plus"></i>Add New List Data Uji</a>
          <thead>
            <tr>
              <th>No</th>
              <th>View</th>
              <th>Nama Device</th>
              <th>Kategori Device</th>
              <th>List Data Uji</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>

            <?php $no = 1;foreach ($datapengujian as $dt) {
	$datauji = $this->Model_pengujian->getAllDataUjiById($dt->id_pengujian);?>
              <tr>
                <td align="center"><?=$no;?></td>
                <td align="center"><a href="" class="viewDataListUji" data-toggle="modal" data-target="#view_data_listuji" data-id_kategori="<?=$dt->id_pengujian?>"><i class="fa fa-folder-open"></i></a></td>
                <td><?=$dt->nama_produk?></td>
                <td><?=$dt->nama_kategori?></td>
                <td><?php foreach ($datauji as $dts) {echo $dts->nama_datauji . '<br>';}?></td>
                <td >
                  <a href="<?=base_url();?>data/listdatauji/hapuslist/<?=$dt->id_pengujian;?>" class = "btn  btn-danger btn-xs" onclick="return confirm('yakin?');"><i class="fa fa-trash-o"></i>Delete</a>
                </td>
              </tr>
              <?php $no++;}?>


            </tbody>
            <tfoot>
              <tr>
                <th>No</th>
                <th>View</th>
                <th>Nama Device</th>
                <th>Kategori Device</th>
                <th>List Data Uji</th>
                <th>Action</th>
              </tr>
            </tfoot>
          </table>
          <tr>

          </div>

          <div class="card mb-3" style="max-width: 540px;">
            <div class="container">
              <div class="row no-gutters">

              </div>
            </div>

          </div>
          <!-- /.box-footer-->
        </div>
        <!-- /.box -->

      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <!-- Modal -->
    <div class="modal fade" id="data_listuji">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title">Add New Data List Uji</h4>
            </div>
            <div class="modal-body">
             <form action="<?=base_url('data/listdatauji/tambahdatauji');?>" method="post" >
               <div class="form-group">
                <select name="id_kat" id="id_kat" class="form-control">
                 <option selected disabled>Select Category</option>
                 <?php foreach ($kategori as $kategori) {?>
                  <option value="<?=$kategori->id_kategori;?>"><?=$kategori->nama_kategori;?></option>
                <?php }?>
              </select>
            </div>
            <div class="form-group">
              <select name="id_prod" id="id_prod" class="form-control">
                <option selected disabled>Select Device</option>
                <?php foreach ($dataproduk as $dt) {?>
                  <option value="<?=$dt->id_produk;?>"><?=$dt->nama_produk;?></option>
                <?php }?>
              </select>
            </div>
            <div class="form-group">
              <label>Pilih data yang akan diuji !</label>
              <select class="form-control select2" multiple="multiple" name="id_uji[]" id="id_uji" data-placeholder="Pilih data yang akan diuji!"
              style="width: 100%;">
              <?php foreach ($datalist as $dt) {?>
                <option value="<?=$dt->id_ujidata;?>"><?=$dt->nama_datauji;?></option>
              <?php }?>
            </select>
          </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Add Data List Uji</button>
        </form>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<!-- /.modal -->


<div class="modal fade" id="view_data_listuji">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span></button>
          <u><h4 class="modal-title" id="formViewListUji">Add New List Data Uji</h4></u>
        </div>
        <div class="modal-body">
         <form action="<?=base_url('data/listdatauji/tambahdatauji');?>" method="post" >

          <div class="row">
            <div class="col-md-12">
              <div class="table-responsive">
                <p><i>Detail Data List Uji Device :</i></p>
                <table class="table table-striped table-bordered">
                 <tbody>
                  <tr>
                    <th>Nama Device</th>
                    <td id="nama_device"></td>
                  </tr>
                  <tr>
                    <th>Kategori Device</th>
                    <td id="ket_device"></td>
                  </tr>
                     <tr>
                    <th>List Data Uji</th>
                    <td id="list_uji"></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default pull-right" data-dismiss="modal">Close</button>
      </form>
    </div>
  </div>
  <!-- /.modal-content -->
</div>
<!-- /.modal-dialog -->
</div>