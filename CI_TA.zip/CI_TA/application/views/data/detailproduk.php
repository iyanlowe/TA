
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Detail Produk : <?= $data_produk['kode_produk'];?>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Examples</a></li>
        <li class="active">Blank page</li>
      </ol>
    </section>

    <!-- Main content -->

    <section class="content">
      <div class="box">
      <!-- Default box -->
    
  <div class="btn-group pull-right">
    <a href="<?=base_url('data/managdata/data');?>" title="Kembali" class = "btn-info btn-sm">
      <i class="fa fa-backward"></i>Kembali
    </a>
    <!-- <a href="" target="_blank" title="Cetak" class = "btn-success btn-sm">
      <i class="fa fa-print"></i>Cetak
    </a> -->
  </div>

<br></br>
<div class="container">
  <div class="card mb-5" style="max-width: 850px;">
<table class="table table-bordered">
    <thead>
      <tr>
        <th width="20%">Nama Perusahaan</th>
        <th>: PT.NET 2 Software Jakarta Pusat</th>
      </tr>
      <tr>
        <th width="20%">Administrator</th>
        <th>: <?= $user['name'];?> </th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Kode Produk</td>
        <td>: <?= $data_produk['kode_produk']; ?></td>
      </tr>
      <tr>
        <td>Nama Produk</td>
        <td>: <?= $data_produk['nama_produk']; ?></td>
      </tr>
      <tr>
        <td>Kategori Produk</td>
        <td>: <?=$data_produk['nama_kategori']?></td>
      </tr>
      <tr>
        <td>Keterangan Produk</td>
        <td>: <?= $data_produk['keterangan_produk']; ?></td>
      </tr>

    </tbody>
  </table>
 

  <br>
      <table class="table table-bordered">
        <thead>
          <tr class="bg-success">
            <th>No</th>
            <th>Kode Device</th>
            <th>Nama Device</th>
            <th>Kategori Device</th>
            <th>Keterangan</th>
          </tr>
        </thead>
        <tbody>
        
          <tr>
            <td>1</td>
            <td><?= $data_produk['kode_produk']; ?></td>
            <td><?= $data_produk['nama_produk']; ?></td>
            <td><?=$data_produk['nama_kategori'];?></td>
            <td><?= $data_produk['keterangan_produk']; ?></td>
          </tr>
        </tbody>
      </table>

       </div>
      <!-- /.box --> 

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
