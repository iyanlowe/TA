<div class="content-wrapper">
  <!-- Content Header (Page header) -->

  <section class="content-header">
    <h1>
      Data Users
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="#">Examples</a></li>
      <li class="active">Data Users</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">

    <!-- Default box -->
    <div class="box">
      <div class="box-body">

       <div class="flash-data" data-flashdata="<?=$this->session->flashdata('message');?>"></div>
       
       <table id="tbldata" class="table table-bordered table-striped">
        <thead>
          <tr>
            <th>No</th>
            <th>Full Name </th>
            <th>Email</th>
            <th>Active Id</th>
            <th>Role Id</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>

          <?php foreach ($users as $users): ?>
            <tr>
              <td align="center"></td>
              <td><?=$users['name'];?></td>
              <td><?=$users['email'];?></td>
              <td align="center"><?=$users['active_id'];?></td>
              <td align="center"><?=$users['role_id'];?></td>
              <td align="center">
                <a href="<?=base_url();?>data/managdata/hapususers/<?=$users['id'];?>" class = "btn  btn-danger btn-xs tombolHapus"><i class="fa fa-trash-o"></i>Delete</a>
              </td>

            <?php endforeach;?>

          </tbody>
          <tfoot>
            <tr>
              <th>No</th>
              <th>Full Name </th>
              <th>Email</th>
              <th>Active Id</th>
              <th>Role Id</th>
              <th>Action</th>
            </tr>
          </tfoot>
        </table>

      </div>
    </div>


    <!-- /.box-footer-->

    <!-- /.box -->

  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<!-- Modal -->
<div class="modal fade" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">Add New Users</h4>
        </div>
        <div class="modal-body">
         <form action="<?=base_url('data/managdata/datausers');?>" method="post" >
           <div class="form-group">
            <input type="text" class="form-control" id="nama_pelanggan" name="nama_pelanggan" placeholder="Nama Pelanggan">
            <small class="form-text text-danger"><?=form_error('nama_pelanggan');?></small>
          </div>
          <div class="form-group">
            <input type="text" class="form-control" id="email" name="email" placeholder="Email">
            <small class="form-text text-danger"><?=form_error('email');?></small>
          </div>
          <div class="form-group">
            <input type="password" class="form-control" id="password" name="password" placeholder="Password">
            <small class="form-text text-danger"><?=form_error('password');?></small>
          </div>
          <div class="form-group">
            <input type="text" class="form-control" id="telepon" name="telepon" placeholder="Telephone">
            <small class="form-text text-danger"><?=form_error('telepon');?></small>
          </div>
          <div class="form-group">
            <input type="text" class="form-control" id="alamat" name="alamat" placeholder="alamat">
            <small class="form-text text-danger"><?=form_error('Alamat');?></small>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Add Users</button>
        </form>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
        <!-- /.modal -->