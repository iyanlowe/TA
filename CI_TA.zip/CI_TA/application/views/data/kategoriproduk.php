<div class="content-wrapper">
  <!-- Content Header (Page header) -->

  <section class="content-header">
    <h1>
      Device Category 
    </h1>
    <ol class="breadcrumb">
      <li><a href="<?=base_url('admin');?>?>"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="<?=base_url('data/managdata/kategoridata');?>">Management Data</a></li>
      <li class="active">Device Category</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">

    <!-- Default box -->
    <div class="box">
      <div class="box-body">

        <div class="flash-data" data-flashdata="<?=$this->session->flashdata('message');?>"></div>
        <a href="" class="btn btn-primary mb-3 mt-5 tombolTambahDataKategori" data-toggle="modal" data-target="#modal-default"><i class="fa fa-plus"></i> Add New Category</a>
        <table id="tbldata" class="table table-bordered table-striped" data-ajax="<?= site_url('data/managdata/getkategoridataajax') ?>">
          <thead>
            <tr>
              <th>No</th>
              <th>View</th>
              <th>Category Name</th>
              <th>Description </th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>

          </tbody>
          <tfoot>
            <tr>
              <th>No</th>
              <th>View</th>
              <th>Category Name</th>
              <th>Description </th>
              <th>Action</th>
            </tr>
          </tfoot>
        </table>
      </div>

      <div class="card mb-3" style="max-width: 540px;">
        <div class="container">
          <div class="row no-gutters">

          </div>
        </div>

      </div>
      <!-- /.box-footer-->
    </div>
    <!-- /.box -->

  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<!-- Modal -->
<div class="modal fade" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title" id="formModalLabelKategori">Add New Category</h4>
        </div>
        <div class="modal-body">
         <form action="<?=base_url('data/managdata/kategoridata');?>" method="post" >
          <input type="hidden" name="id_kategori" id="id_kategori">
          <div class="form-group">
            <input type="text" class="form-control" id="nama_kategori" name="nama_kategori" placeholder="Category Name">
            <?=form_error('nama_kategori', '<small class="text-danger pl-3">', '</small>');?>
          </div>
          <div class="form-group">
            <input type="text" class="form-control" id="keterangan" name="keterangan" placeholder="Description">
            <?=form_error('keterangan', '<small class="text-danger pl-3">', '</small>');?>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Add Category</button>
        </form>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>

<div class="modal fade" id="modal-default1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title" id="formViewKategori">Add New Kategori</h4>
        </div>
        <div class="modal-body">
         <form action="<?=base_url('data/managdata/kategoridata');?>" method="post" >
          <input type="hidden" name="id_kategori" id="id_kategori">
          <div class="row">
            <div class="col-md-12">
              <div class="table-responsive">
                <p><i>Detailed Device Category Data :</i></p>
                <table class="table table-striped table-bordered">
                 <tbody>
                  <tr>
                    <th>Company Name</th>
                    <td>PT.NET 2 Software Jakarta</td>
                  </tr>
                  <tr>
                    <th>Administrator</th>
                    <td><?=$user['name'];?></td>
                  </tr>
                  <tr>
                    <th>Category Name</th>
                    <td id="nama_kat"></td>
                  </tr>
                  <tr>
                    <th>Description</th>
                    <td id="ket_kat"></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default pull-right" data-dismiss="modal">Close</button>
      </form>
    </div>
  </div>
  <!-- /.modal-content -->
</div>
<!-- /.modal-dialog -->
</div>


