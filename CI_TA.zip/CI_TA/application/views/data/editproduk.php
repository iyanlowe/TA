 <div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Edit Produk : <?= $data_produk['kode_produk'];?>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="#">Examples</a></li>
      <li class="active">Blank page</li>
    </ol>
  </section>

  <!-- Main content -->

  <section class="content">
    <div class="box">
      <div class="box-body">
        <form action="" method="post">
          <input type="hidden" name="id_produk" value="<?= $data_produk['id_produk'];?>" >

          <!-- Default box -->
          <div class="form-group row">
            <label class="col-sm-2 col-form-label">Kode Produk</label>
            <div class="col-sm-7">
              <input type="text" name="kode_produk" id="kode_produk" class="form-control" value="<?= $data_produk['kode_produk'];?>">
            </div>
          </div>

          <div class="form-group row">
            <label class="col-sm-2 col-form-label">Nama Produk</label>
            <div class="col-sm-7">
              <input type="text" name="nama_produk" id="nama_produk" class="form-control" value="<?= $data_produk['nama_produk'];?>">
            </div>
        </div>

          <div class="form-group row"> 
            <label class="col-sm-2 col-form-label">Kategori produk</label> 
                <div class="col-sm-7">
            <select name="id_kat" id="id_kat" class="form-control" >
                 <?php foreach ($kategori as $dt) {?>
                  <option value="<?=$dt->id_kategori;?>" <?php if($dt->id_kategori==$data_produk['id_kategori']){echo "selected";} ?> ><?=$dt->nama_kategori;?></option>
                 <!--    <option value="<?=$dt->id_kategori;?>"><?=$dt->nama_kategori;?></option>
                  -->
                <?php }?> 
            </select>
          </div>
          </div>

          <div class="form-group row">
            <label class="col-sm-2 col-form-label">Keterangan Produk</label>
            <div class="col-sm-7">
              <input type="text" name="keterangan_produk" id="keterangan_produk" class="form-control" value="<?= $data_produk['keterangan_produk'];?>">
            </div>
          </div>

          <div class="form-group">
            <label  class="col-md-2 control-label"></label>
            <div class="col-md-5">
              <button class="bnt btn-success btn-lg" name="edit" type="submit">
                <i class="fa fa-save"></i>Edit Data
              </button>
              <button  class="bnt btn-info btn-lg" name="kembali" type="kembali" >
                <i class="fa fa-times"></i>Kembali
              </button>
            </div>
          </div>

        </form>


      </div>
    </div>
  </section>

  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
