<div class="content-wrapper">
  <!-- Content Header (Page header) -->

  <section class="content-header">
    <h1>
      Device Data
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i>Menu Management</a></li>
      <li class="active">Device Data</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">

    <!-- Default box -->
    <div class="box">
      <div class="box-body">
        <div class="flash-data" data-flashdata="<?=$this->session->flashdata('message');?>"></div>
        <!-- <div class="flash-data-danger" data-flashdata="<?=$this->session->flashdata('message-danger');?>"></div> -->
        <a href="" class="btn btn-primary mb-3 mt-5 tombolTambahDevice" data-toggle="modal" data-target="#data_device"><i class="fa fa-plus"></i> Add New Device Data</a>
        <table id="tbldata" class="table table-bordered table-striped">
          <thead>
            <tr>
              <th>No</th>
              <th>View</th>
              <th>SN Number</th>
              <th>Device Type Name</th>
              <th>Device Category</th>
              <th>Description</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>

            <?php $no = 1;foreach ($datadevice as $dd) {
             $datakategori = $this->Model_datadevice->getAllDataKategoriById($dd->id_device);?>
             <tr>
              <td align="center"><?=$no;?></td>
              <td align="center"><a href="" class="tampilModalDevice"  data-toggle="modal" data-target="#modal-viewdevice" data-id_device="<?=$dd->id_device?>"><i class="fa fa-folder-open"></i></a></td>
              <td><?=$dd->kode_device?></td>
              <td><?=$dd->nama_typedevice?></td>
              <td><?php foreach ($datakategori as $dk) {echo $dk->nama_kategori . '<br>';}?></td>
              <td><?=$dd->ket_typedevice?></td>
              <td>
                <a href="" class="btn btn-warning btn-xs tampilModalUbahDevice" data-toggle="modal" data-target="#data_device" data-id_device="<?=$dd->id_device?>"><i class="fa fa-edit"></i>Edit</a>
                <a href="<?=base_url();?>data/datadevice/hapusdevice/<?=$dd->id_device;?>" class = "btn  btn-danger btn-xs tombolHapus" ><i class="fa fa-trash-o"></i>Delete</a>
              </td>
            </tr>
            <?php $no++;}?>


          </tbody>
          <tfoot>
            <tr>
             <th>No</th>
             <th>View</th>
             <th>Nomor SN</th>
             <th>Type Device</th>
             <th>Kategori Device</th>
             <th>Keterangan</th>
             <th>Action</th>
           </tr>
         </tfoot>
       </table>
       <tr>

       </div>

       <div class="card mb-3" style="max-width: 540px;">
        <div class="container">
          <div class="row no-gutters">

          </div>
        </div>

      </div>
      <!-- /.box-footer-->
    </div>
    <!-- /.box -->

  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<!-- Modal -->
<div class="modal fade" id="data_device">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title" id="formModalLabeldevice">Add New Device Data</h4>
        </div>
        <div class="modal-body">
         <form action="<?=base_url('data/datadevice');?>" method="post" >
           <input type="hidden" name="id_device" id="id_device">
          <div class="form-group">
            <input type="text" class="form-control" id="kode_device" name="kode_device" placeholder="SN Number">
            <?=form_error('kode_device', '<small class="text-danger pl-3">', '</small>');?>
          </div>

          <div class="form-group">
            <select name="id_typedev" id="id_typedev" class="form-control">
              <option selected disabled>Select Device Type Name</option>
              <?php foreach ($typedevice as $dt) {?>
                <option value="<?=$dt->id_typedevice;?>"><?=$dt->nama_typedevice;?></option>
              <?php }?>
            </select>
          </div>
          <div class="form-group">
            <label>Select the device category to be tested !</label>
            <select class="form-control" id="tesel" multiple="multiple" name="id_kate[]" id="id_kate" data-placeholder="Select the device category!"
            style="width: 100%;">
            <?php foreach ($datakategoris as $dk) {?>
              <option value="<?=$dk->id_kategori;?>"><?=$dk->nama_kategori;?></option>
            <?php }?>
          </select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Add Data Device</button>
      </form>
    </div>
  </div>
  <!-- /.modal-content -->
</div>
<!-- /.modal-dialog -->
</div>
<!-- /.modal -->


<div class="modal fade" id="modal-viewdevice">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span></button>
          <u><h4 class="modal-title" id="formViewDevice">Add New List Data Uji</h4></u>
        </div>
        <div class="modal-body">
         <form action="" method="post" >
          <input type="hidden" name="id_device" id="id_device">

          <div class="row">
            <div class="col-md-12">
              <div class="table-responsive">
                <p><i>Detail Data Device :</i></p>
                <table class="table table-striped table-bordered">
                 <tbody>
                  <tr>
                    <th>Nomor SN</th>
                    <td id="kodedevice"></td>
                  </tr>
                  <tr>
                    <th>Type Device</th>
                    <td id="type_device"></td>
                  </tr>
                  <tr>
                    <th>Kategori Device</th>
                      <td><?php foreach ($datakategori as $dk) {echo $dk->nama_kategori . '<br>';}?></td>
                  </tr>
                  <tr>
                    <th>Keterangan</th>
                    <td id="ket_device"></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default pull-right" data-dismiss="modal">Close</button>
      </form>
    </div>
  </div>
  <!-- /.modal-content -->
</div>
<!-- /.modal-dialog -->
</div>

