
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Detail Data Users
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Examples</a></li>
        <li class="active">Detail Data users</li>
      </ol>
    </section>

    <!-- Main content -->

    <section class="content">
      <div class="box">

      <!-- Default box -->
      <p class="pull-right mt-3">
  <div class="btn-group pull-right">
    <a href="<?=base_url('data/managdata/datausers');?>" title="Kembali" class = "btn-info btn-sm">
      <i class="fa fa-backward"></i>Kembali
    </a>
    <!-- <a href="" target="_blank" title="Cetak" class = "btn-success btn-sm">
      <i class="fa fa-print"></i>Cetak
    </a> -->
  </div>
</p>

<div class="container">
<div class="clearfix"></div>
<br>
<table class="table table-bordered">
    <thead>
      <tr>
        <th width="20%">Nama Perusahaan</th>
        <th>: PT.NET 2 Software Jakarta Pusat</th>
      </tr>
      <tr>
        <th width="20%">Administrator</th>
        <th>: <?= $user['name'];?> </th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Nama Users</td>
        <td>: <?= $pelanggan['nama_pelanggan']; ?></td>
      </tr>
      <tr>
        <td>Email</td>
        <td>: <?= $pelanggan['email']; ?></td>
      </tr>
      <tr>
        <td>Password</td>
        <td>: <?=$pelanggan['password'];?></td>
      </tr>
      <tr>
        <td>Nomor Telephone</td>
        <td>: <?= $pelanggan['telepon']; ?></td>
      </tr>
       <tr>
        <td>Alamat</td>
        <td>: <?= $pelanggan['alamat']; ?></td>
      </tr>

    </tbody>
  </table>
  </div>

<!--   <hr>
      <table class="table table-bordered" width="100%">
        <thead>
          <tr class="bg-success">
            <th>No</th>
            <th>Kode Produk</th>
            <th>Nama Produk</th>
            <th>Jumlah </th>
            <th>Harga</th>
            <th>Sub Total</th>
          </tr>
        </thead>
        <tbody>
          <?php $i=1; foreach ($transaksi as $transaksi){ ?>
          <tr>
            <td><?php echo $i; ?></td>
            <td><?php echo $transaksi->kode_produk?></td>
            <td><?php echo $transaksi->nama_produk ?></td>
            <td><?php echo number_format($transaksi->jumlah) ?></td>
            <td><?php echo number_format($transaksi->harga) ?></td>
            <td><?php echo number_format($transaksi->total_harga) ?></td>
          </tr>
          <?php $i++; } ?>
        </tbody>
      </table> -->
      <!-- /.box --> 

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
