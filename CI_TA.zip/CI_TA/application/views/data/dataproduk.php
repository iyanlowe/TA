<div class="content-wrapper">
  <!-- Content Header (Page header) -->

  <section class="content-header">
    <h1>
      Data Device
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="#">Management Data</a></li>
      <li class="active">Data Device</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">

    <!-- Default box -->
    <div class="box">
      <div class="box-body">

        <?=$this->session->flashdata('message');?>

        <table id="tbdata" class="table table-bordered table-striped">
          <a href="" class="btn btn-primary" data-toggle="modal" data-target="#modal-default"><i class="fa fa-plus"></i> Add New Device</a>
          <thead>
            <tr>
              <th>View</th>
              <th>Kode Device</th>
              <th>Nama Device</th>
              <th>Kategori Device</th>
              <th>Keterangan Device</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>

            <?php foreach ($dataproduk as $dp): ?>

              <tr>
                <td align="center"><a href="<?=base_url();?>data/managdata/detail/<?=$dp['id_produk'];?>"><i class="fa fa-folder-open"></i></a></td>
                <td><?=$dp['kode_produk'];?></td>
                <td><?=$dp['nama_produk'];?></td>
                <td><?=$dp['nama_kategori'];?></td>
                <td><?=$dp['keterangan_produk'];?></td>
                <td align="center">
                  <a href="<?=base_url();?>data/managdata/detail/<?=$dp['id_produk'];?>" class="btn  btn-success btn-xs"><i class="fa fa-eye"></i>Detail</a>
                  <a href="<?=base_url();?>data/managdata/edit/<?=$dp['id_produk'];?>" class="btn  btn-warning btn-xs"><i class="fa fa-edit"></i>Edit</a>
                  <a href="<?=base_url();?>data/managdata/hapus/<?=$dp['id_produk'];?>" class = "btn  btn-danger btn-xs" onclick="return confirm('yakin?');"><i class="fa fa-trash-o"></i>Delete</a>

                </td>

              <?php endforeach;?>

            </tbody>
            <tfoot>
           <th>View</th>
              <th>Kode Device</th>
              <th>Nama Device</th>
              <th>Kategori Device</th>
              <th>Keterangan Device</th>
              <th>Action</th>
            </tfoot>
          </table>

        </div>

        <!-- /.box-footer-->
      </div>
      <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Modal -->
  <div class="modal fade" id="modal-default">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Add New Product</h4>
          </div>
          <div class="modal-body">
           <form action="<?=base_url('data/managdata/data');?>" method="post" >
             <div class="form-group">
              <input type="text" class="form-control" id="kode_produk" name="kode_produk" placeholder="Kode Produk">
              <?=form_error('kode_produk', '<div class="alert alert-danger" role="alert">', '</div>')?>
            </div>
            <div class="form-group">
              <input type="text" class="form-control" id="nama_produk" name="nama_produk" placeholder="nama_produk">
              <?=form_error('nama_produk', '<div class="alert alert-danger" role="alert">', '</div>')?>
            </div>
            <div class="form-group">
              <select name="id_kat" id="id_kat" class="form-control">
                <option selected disabled>Select Category</option>
                <?php foreach ($kategori as $dt) {?>
                  <option value="<?=$dt->id_kategori;?>"><?=$dt->nama_kategori;?></option>
                <?php }?>


              </select>
            </div>
            <div class="form-group">
              <input type="text" class="form-control" id="keterangan_produk" name="keterangan_produk" placeholder="Keterangan Produk">
              <?=form_error('keterangan_produk', '<div class="alert alert-danger" role="alert">', '</div>')?>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Add Product</button>
          </form>
        </div>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
        <!-- /.modal -->