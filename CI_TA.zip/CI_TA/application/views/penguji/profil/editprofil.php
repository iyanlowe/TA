

<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- Page Heading -->
  <h1 class="h3 mb-4 text-gray-800">Edit Profile</h1>
  <div class="card mb-3">
    <div class="container mb-5">
      <?= $this->session->flashdata('message'); ?>
      <br>
      <?= form_open_multipart('penguji/penguji/editprofil');?>
      <!-- Default box -->
      <div class="form-group row">
        <label class="col-sm-2 col-form-label">Email</label>
        <div class="col-sm-7">
          <input type="text" name="email" id="email" class="form-control" value="<?=$user['email'];?>" readonly>
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-2 col-form-label">Password</label>
        <div class="col-sm-7">
          <input type="password" name="password" id="password" class="form-control" value="<?=$user['password'];?>" readonly>
        </div>
      </div>

      <div class="form-group row">
        <label class="col-sm-2 col-form-label">Full name</label>
        <div class="col-sm-7">
          <input type="text" name="name" id="name" class="form-control" value="<?=$user['name']?>">
          <?= form_error('name','<small class="text-danger pl-3">', '</small>');?>
        </div>
      </div> 
      <div class="form-group row">
        <div class="col-sm-2 col-form-label">Picture</div> 
        <div class="col-sm-10">
          <div class="row">
            <div class="col-sm-3">
              <img src="<?= base_url('assets/admin/dist/img/') . $user['image'];?>" class="img-thumbnail">
            </div>
            <div class="col-sm-5">
              <div class="custom-file">
                <input type="file" name ="image" class="form-control"  placeholder="Upload Icon Baru" 
                value="">
              </div>
            </div>
          </div>
        </div>          

      </div> 

      <div class="form-group">
        <label  class="col-md-2 control-label"></label>
        <div class="col-md-5">
          <button class="bnt btn-primary btn-lg pull-right" name="edit" type="submit">Edit Data
          </button>
        </div>
      </div>

    </form>  
  </div>
</div>
</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
