<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- Page Heading -->
  <h1 class="h3 mb-4 text-gray-800">Test Device : <?=$device['kode_device']?></h1>
  <div class="card mb-3">
    <div class="row no-gutters">
      <div class="container mb-3">
       <br>
       
       <form action="<?=base_url('penguji/penguji/hasil_uji')?>" method="post">
        <div class="container">
          <div class="table-responsive">
            <table class="table table-striped table-bordered">
             <tbody>
              <tr>
                <th>Nomor SN</th>
                <td><?=$device['kode_device'];?></td>
              </tr>
              <tr>
                <th>Nama Type Device</th>
                <td><?=$device['nama_typedevice'];?></td>
              </tr>
              <tr>
                <th>Kategori Device</th>
                <td><?php foreach ($datakategori as $dk) {echo $dk->nama_kategori . '<br>';}?></td>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="form-group row">
          <div class="col-sm-7">
            <input type="hidden" name="device_uji" id="device_uji" class="form-control" value="<?=$device['id_device'];?>" readonly>
          </div>
        </div>
        <label class="md-3"> Data yang diuji :</label><br>
        <div class="row">


          <?php
          $i=0;
          foreach ($datakategoris as $dt) {?>
            <div class="col-sm-4">
             <div class="card">
              <div class="card-body">
                <strong><?=$dt->nama_kategori;?></strong><br>
                <?php $datauji=$this->Api_modeldatadevice->getAllDataUjiByCat($dt->id_kategori); $j=0;
                foreach ($datauji as $dts) {?>
                  <input type="checkbox" name="check_list[]" id="id_uji[]" alt="Checkbox" value="<?=$dts->id_ujidata;?>"><?=$dts->nama_datauji;?><br>
                 <?php $j++;}$i++;?>
               </div>
             </div>
           </div>
         <?php }?>
       </div>
      <br>
      <div class="form-group mt-3" style="width: 450px;">
        <select name="id_hasilpil" id="id_hasilpil" class="form-control">
          <option selected disabled>Pilih Hasil</option>
          <?php foreach ($hasilpilih as $hapil) {?>
            <option value="<?=$hapil->id_hasilpilih;?>"><?=$hapil->nama_hasilpilih;?></option>
          <?php }?>
        </select>
      </div>
      <div class="form-group">
        <input type="text" class="form-control" id="ket_uji" name="ket_uji" placeholder="Masukan Keterangan Uji" style="width: 450px;">
        <?=form_error('kode_device', '<small class="text-danger pl-3">', '</small>');?>
      </div>
    </div>
    <br>
    <button type="submit" class="btn btn-success" style="float: right;">Simpan Hasil Uji</button>
    <a href="<?=base_url('penguji/penguji/ujidevice')?>" class="btn btn-danger backToCheck" style="float: right;">Kembali</a>
  </form>
</div>
</div>
</div>
</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
