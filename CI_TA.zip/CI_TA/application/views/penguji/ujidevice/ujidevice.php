<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- Page Heading -->
  <h1 class="h3 mb-4 text-gray-800">Device Test</h1>
  <div class="card mb-3">
    <div class="container">

      <form action="<?=base_url('penguji/penguji/ujidevice');?>" method="post">
        <input type="hidden" name="id_device" id="id_device">

        <br>
        <?= $this->session->flashdata('message'); ?>
        <div class="form-group form-group-lg">
          <label  class="col-md-2 control-label">SN Number</label>
          <div class="col-md-7">
            <input type="text" name ="no_sn" id="no_sn" class="form-control"  placeholder="Enter the SN number" value="<?= set_value('no_sn');?>">
            <?=form_error('no_sn', '<small class="text-danger pl-3">', '</small>');?>
          </div>
        </div>
        <div class="form-group form-group-lg">
          <label  class="col-md-2 control-label">Type Device</label>
          <div class="col-md-7">
            <select name="id_typedev" id="id_typedev" class="form-control">
              <option selected disabled>Select Device Type Name</option>
              <?php foreach ($typedevice as $dt) {?>
                <option value="<?=$dt->id_typedevice;?>"><?=$dt->nama_typedevice;?></option>
              <?php }?>
            </select>
          </div>
        </div>
        <div class="form-group">
          <label  class="col-md-2 control-label"></label>
          <div class="col-md-5">
            <button class="bnt btn-primary btn-lg" name="submit" type="submit">Check Device
            </button>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- /.container-fluid -->
</div>
<!-- End of Main Content -->

