
<!-- Footer -->
<footer class="sticky-footer bg-white">
  <div class="container my-auto">
    <div class="copyright text-center my-auto">
      <span>CreatedBy &copy; PT.NET2Software Jakarta 2019. </span>
    </div>
  </div>
</footer>
<!-- End of Footer -->


</div>
<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
  <i class="fas fa-angle-up"></i>
</a>

<!-- Bootstrap core JavaScript-->
<script src="<?=base_url()?>assets/penguji/vendor/jquery/jquery.min.js"></script>
<script src="<?=base_url()?>assets/penguji/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="<?=base_url()?>assets/penguji/vendor/jquery-easing/jquery.easing.min.js"></script>
<script src="<?=base_url()?>assets/admin/plugins/datatables/jquery.dataTables.min.js"></script>
<!-- Custom scripts for all pages-->
<script src="<?=base_url()?>assets/penguji/js/sb-admin-2.min.js"></script>
 <script src="<?=base_url();?>assets/sweetalert/sweetalert.min.js"></script>
 <script src="<?=base_url();?>assets/sweetalert/sweetalert-dev.js"></script>
 <script src="<?=base_url()?>assets/admin/dist/js/myscript.js"></script>

 <script>
  $(document).ready(function () {

  $("#FormCetak").submit(function(e){
          e.preventDefault();
          var id = $("#date").val();
          console.log(id);
          var url = "<?=base_url('con_report/laporan/filter/');?>" 
        });

    $('.custom-file-input').on('change', function(){

      let fileName = $(this).val().split('\\').pop();
      $(this).next('.custom-file-label').addClass("selected").html(fileName);
    });

    let datatable = $('#tbldatapenguji').DataTable({
      'ajax'        : $(this).attr('data-ajax'),
      'paging'      : false,
      'lengthChange': false,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false,
    });
});

</script>


</body>

</html>
