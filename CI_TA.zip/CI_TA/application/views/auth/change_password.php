<body>
	<div class="main-wrapper">
		<!-- ============================================================== -->
		<!-- Preloader - style you can find in spinners.css -->
		<!-- ============================================================== -->
		<div class="preloader">
			<div class="lds-ripple">
				<div class="lds-pos"></div>
				<div class="lds-pos"></div>
			</div>
		</div>
		<!-- ============================================================== -->
		<!-- Preloader - style you can find in spinners.css -->
		<!-- ============================================================== -->
		<!-- ============================================================== -->
		<!-- Login box.scss -->
		<!-- ============================================================== -->
		<div class="auth-wrapper d-flex no-block justify-content-center align-items-center position-relative"
		style="background:url(<?= base_url() ?>/assets/template//images/big/auth-bg.jpg) no-repeat center center;">
		<div class="auth-box row">
			<div class="col-lg-12 col-md-7 bg-white">
				<div class="p-3">
					<div class="text-center">
						<img src="<?= base_url() ?>/assets/template//images/big/icon.png" alt="wrapkit">
					</div>
					<h2 class="mt-3 text-center"><?= $title ?></h2>

					<?= $this->session->flashdata('message'); ?>
					<form action="<?= base_url('auth/changepassword');?>" method="post" class="form-group">
						<div class="row">
							<div class="col-lg-12">
								<div class="form-group">
									<label class="text-dark" for="uname">Password</label>
									<input class="form-control" id="password" name="password" type="password"
									placeholder="Password" value="<?= set_value('password');?>">
									<?= form_error('password','<small class="text-danger pl-3">', '</small>');?>
								</div>
							</div>
							<div class="col-lg-12">
								<div class="form-group">
									<label class="text-dark" for="pwd">Confirmasi Password</label>
									<input class="form-control" id="confpass" name="confpass" type="password"
									placeholder="Confirm Password" value="<?= set_value('password');?>">
									<?= form_error('password2','<small class="text-danger pl-3">', '</small>');?>
								</div>
							</div>
							<div class="col-lg-12 text-center">
								<button type="submit" class="btn btn-block btn-dark">Submit</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>