<body>
    <div class="main-wrapper">
        <!-- ============================================================== -->
        <!-- Preloader - style you can find in spinners.css -->
        <!-- ============================================================== -->
        <div class="preloader">
            <div class="lds-ripple">
                <div class="lds-pos"></div>
                <div class="lds-pos"></div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- Preloader - style you can find in spinners.css -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Login box.scss -->
        <!-- ============================================================== -->
        <div class="auth-wrapper d-flex no-block justify-content-center align-items-center position-relative" 
        style="background:url(<?= base_url() ?>/assets/template//images/big/auth-bg.jpg) no-repeat center center;">
        <div class="auth-box row">
            <div class="col-lg-6 col-md-4 modal-bg-img"  style="background-image: url(<?= base_url() ?>assets/template/images/big/logo.jpg);" >
            </div>
            <div class="col-lg-6 col-md-8 bg-white">
                <div class="p-3">
                    <div class="text-center">
                        <img src="<?= base_url() ?>/assets/template//images/browser/sketch.jpg" alt="wrapkit">
                    </div>
                    <h2 class="mt-3 text-center">Sign In</h2>

                    <p class="text-center">Enter your email address and password to access admin panel.</p>
                    <?= $this->session->flashdata('message'); ?>
                    <div class="col-lg-12 text-right mt-5">
                        <a href="" data-toggle="modal" data-target="#forgotpassword-modal"  class="text-info">Forgot Password?</a>
                    </div>
                    <form class="mt-4" action="<?= base_url('auth');?>" method="post">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="text-dark" for="uname">Email</label>
                                    <input class="form-control" id="email" name="email" type="email"
                                    placeholder="Input your Email" value="<?= set_value('email');?>">
                                    <?= form_error('email','<small class="text-danger pl-3">', '</small>');?>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="text-dark" for="pwd">Password</label>
                                    <input class="form-control" id="password" name="password" type="password"
                                    placeholder="Input your Password" value="<?= set_value('password');?>">
                                    <?= form_error('password','<small class="text-danger pl-3">', '</small>');?>
                                </div>
                            </div>
                            <div class="col-lg-12 text-center">
                                <button type="submit" class="btn btn-block btn-dark">Sign In</button>
                            </div>
                            <div class="col-lg-12 text-center mt-3">
                                Don't have an account? <button type="button" data-toggle="modal" data-target="#signup-modal" class="btn btn-block text-danger">Sign Up</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Login box.scss -->
    <!-- ============================================================== -->
</div>

<!-- Signup modal content -->
<div id="signup-modal" class="modal fade" tabindex="-1" role="dialog"
aria-hidden="true">
<div class="modal-dialog">
    <div class="modal-content">

        <div class="modal-body">
            <div class="text-center mt-2 mb-4">
                <a href="index.html" class="text-success">
                    <span><img class="mr-2" src="<?= base_url() ?>/assets/template//images/coba.png"
                        alt="" height="18"><img
                        src="<?= base_url() ?>/assets/template//images/logo-text.png" alt=""
                        height="18"></span>
                    </a>
                    <?= $this->session->flashdata('message'); ?>
                </div>

                <form class="pl-3 pr-3" action="<?= base_url('auth/register'); ?>" method="post">

                    <div class="form-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>First Name</label>
                                    <input type="text" class="form-control" name="fname" placeholder="Input First Name"  value="<?= set_value('fname');?>">
                                    <?= form_error('fname','<small class="text-danger pl-3">', '</small>');?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Last Name</label>
                                    <input type="text" name="lname" class="form-control" placeholder="Input Last Name" value="<?= set_value('lname');?>">
                                    <?= form_error('lname','<small class="text-danger pl-3">', '</small>');?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="emailaddress">Email address</label>
                        <input class="form-control" type="email" name="email" id="email"
                        required="" placeholder="Input Email Address" value="<?= set_value('email');?>">
                        <?= form_error('email','<small class="text-danger pl-3">', '</small>');?>
                    </div>

                    <div class="form-group">

                        <label>Select Pekerjaan</label>
                                <!-- <h6 class="card-subtitle">To use add <code>.input-group-prepend</code> class to the div
                                </h6> -->
                                
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <label class="input-group-text" for="ui-pekerjaan">Options</label>
                                    </div>
                                    <select class="custom-select" name="role_id" id="ui-pekerjaan" value="<?= set_value('role_id');?>">
                                        <option selected>Choose...</option>
                                        <option value="1">Petugas 1</option>
                                        <option value="2">Petugas 2</option>
                                        <option value="3">Petugas 3</option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Password</label>
                                            <input type="password" class="form-control" name="password" placeholder="Input Password"  value="<?= set_value('password');?>">
                                            <?= form_error('password','<small class="text-danger pl-3">', '</small>');?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Confirmasi Password</label>
                                            <input type="password" name="confpass" class="form-control" placeholder="Confirmasi Password" value="<?= set_value('confpass');?>">
                                            <?= form_error('confpass','<small class="text-danger pl-3">', '</small>');?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input"
                                    id="customCheck1">
                                    <label class="custom-control-label" for="customCheck1">I
                                        accept <a href="#">Terms and Conditions</a></label>
                                    </div>
                                </div>

                                <div class="form-group text-center">
                                    <button class="btn btn-primary" type="submit">Sign Up
                                    Free</button>
                                </div>

                            </form>

                        </div>
                    </div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->

            <!-- Forgot Password modal content -->
            <div id="forgotpassword-modal" class="modal fade" tabindex="-1" role="dialog"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">

                    <div class="modal-body">
                        <div class="text-center mt-2 mb-4">
                            <a href="#" class="text-success">
                                <span><img class="mr-2" src="<?= base_url() ?>/assets/template/images/coba.png"
                                    alt="" height="18"><img
                                    src="<?= base_url() ?>/assets/template//images/logo-text.png" alt=""
                                    height="18"></span>
                                </a>
                                <?= $this->session->flashdata('message'); ?>
                            </div>

                            <form class="pl-3 pr-3" action="<?= base_url('auth/forgotpassword'); ?>" method="post">


                                <div class="form-group">
                                    <label for="emailaddress">Email address</label>
                                    <input class="form-control" type="email" name="email" id="email"
                                    required="" placeholder="Input Email Address" value="<?= set_value('email');?>">
                                    <?= form_error('email','<small class="text-danger pl-3">', '</small>');?>
                                </div>
                                <div class="form-group text-center">
                                    <button class="btn btn-primary" type="submit">Submit</button>
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Back</button>
                                </div>

                            </form>

                        </div>
                    </div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
        </div><!-- /.modal -->