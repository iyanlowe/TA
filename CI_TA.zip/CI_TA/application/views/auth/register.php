
<body>
	<!-- Main Content -->
	<div class="container-fluid">
		<div class="row main-content bg-success ">
			
			<div class="col-md-12 col-xs-12 col-sm-12 login_form ">
				<div class="container-fluid text-center col-md-12">
					<div class="row text-center">
						<h2><?php echo $title; ?></h2>
						<?= $this->session->flashdata('message'); ?>
					</div>
						<form action="<?= base_url('auth/register');?>" method="post" class="form-group">
							<p style="text-align: right;">Have Account? <a href="<?= base_url('auth'); ?>">Login</a></p>
					  <div class="row">
					    <div class="form-group col-md-6">
					      <input type="text" class="form__input" id="fname" name="fname" placeholder="First Name" value="<?= set_value('fname');?>">
        					<?= form_error('fname','<small class="text-danger pl-3">', '</small>');?>
					    </div>
					     <div class="form-group col-md-6">
					      <input type="text" class="form__input" id="lname" name="lname" placeholder="Last Name" value="<?= set_value('lname');?>">
        					<?= form_error('lname','<small class="text-danger pl-3">', '</small>');?>
					    </div>
					</div>
					  <div class="form-group">
					    <input type="email" class="form__input" id="email" name="email" placeholder="Email" value="<?= set_value('email');?>">
        					<?= form_error('email','<small class="text-danger pl-3">', '</small>');?>
					  </div>
					  <div class="form-group">
					   <select id="role_id" name="role_id" class="form__input" value="<?= set_value('role_id');?>">
                            <option value="">Choose your job</option>
                            <option value="2">Petugas 1</option>
                            <option value="3">Petugas 2</option>
                            <option value="4">Petugas 3</option>
                            <option value="5">Petugas 4</option>
                        </select>
                    </div>
					  <div class="row">
					    <div class="form-group col-md-6">
					      <input type="password" class="form__input" id="password" name="password" placeholder="Password" value="<?= set_value('password');?>">
       					 <?= form_error('Password','<small class="text-danger pl-3">', '</small>');?>
					    </div>
					    <div class="form-group col-md-6">
					      <input type="password" class="form__input" id="confpass" name="confpass" placeholder="Confirm Password" value="<?= set_value('confpass');?>">
        					<?= form_error('confpass','<small class="text-danger pl-3">', '</small>');?>
					    </div>
					  </div>
					 <input type="submit" value="Sign In" class="btn" style="text-align: center;">
								<p style="text-align: left;"><a href="<?= base_url('auth/forgotpassword'); ?>">Forgot Password?</a></p>
					</form>
				</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Footer -->
	<div class="container-fluid text-center footer">
		Coded with &hearts; by <a href="https://bit.ly/yinkaenoch">BPBD Indramayu</a></p>
	</div>
</body>