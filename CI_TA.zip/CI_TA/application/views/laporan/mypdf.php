<!DOCTYPE html>
<html>
<head>
	<title>Laporan Quality Control</title>
	<link rel="icon" type="image/png" href="<?=base_url('assets/admin/jaring.logo1.png')?>">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<style>
		.line-title{
			border: 0;
			border-style: inset; 
			border-top: 1px solid #000;
		}

	</style>

</head>
<body>
 <img src="assets/admin/jaring.logo1.png" style="position: absolute; width: 85px; height: auto;">
 <table style="width: 100%;">
 	<tr>
 		<td align="center">
 			<span style="line-height: 1.6; font-weight: bold;">
 				PT. NET 2 SOFTWARE JARING SOLUSI APLIKASI
 				<br>JAKARTA PUSAT, INDONESIA
 			</span>
 		</td>
 	</tr>
 </table>
 <hr class="line-title">
 <p align="center">
 	Data Laporan Hasil Uji Quality Control<br>
 	Tahun 2019
 </p>
 <table class="table table-bordered" style="border-width: 2px;">
  <thead>
    <tr>
      <th>No</th>
      <th>Nomor SN</th>
      <th>Nama Type Device</th>
      <th>Tanggal Uji</th>
      <th>Hasil Uji</th>
      <th>Keterangan</th>
    </tr>
  </thead>
  <tbody>  


   <?php $no = 1; foreach ($hasil_uji as $hu) {
    ?>
     <tr>
      <td align="center"><?=$no;?></td>
      <td><?=$hu->kode_device?></td>
      <td><?=$hu->nama_typedevice?></td>
      <td><?= $hu->date_created; ?></td>
      <td><?=$hu->nama_hasilpilih?></td>
      <td><?=$hu->keterangan?></td>

    </tr>

    <?php $no++;}?>


  </tbody>

</table>

</body>
</html>