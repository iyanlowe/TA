<div class="content-wrapper">
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<h1>
			Filter Report
		</h1>
		<ol class="breadcrumb">
			<li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
			<li><a href="#">Report Data</a></li>
			<li class="active">Filter Report </li>
		</ol>
	</section>

	<!-- Main content -->
	<section class="content">

		<!-- Default box -->
		<div class="box">
			<div class="box-body">
				<div class="col-md-2">
					<form action="<?=base_url('con_report/laporan/filter/');?>">
						<div class="form-group">
							<select name="date" id="date" class="form-control">
								<option>Show All</option>
								<?php foreach ($date as $dt) {?>
									<option value="<?=$dt->date_created;?>"><?= $dt->date_created; ?></option>
								<?php }?>
							</select>
						</div>
						<button type="submit" class="btn btn-primary">Show Data</button>
					</form>
				</div>
				<a href="<?=base_url('con_report/laporan');?>" target="_blank" class="btn btn-success mb-3 mt-5"><i class="fa fa-print"></i> Generate PDF</a>
				<!-- <a href="<?=base_url('con_report/export_excel/export_data');?>" target="_blank" class="btn btn-success mb-3 mt-5"><i class="fa fa-print"></i> Generate EXCEL</a> -->

				<table id="tbldata" class="table table-bordered table-striped">
					<thead>
						<tr>
							<th>No</th>
							<th>View</th>
							<th>Nomor SN</th>
							<th>Nama Device</th>
							<th>Kategori Device</th>
							<th>Tanggal Uji</th>
							<th>Data Yang Di Uji</th>
							<th>Hasil Uji</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>  

						<?php $no = 1; foreach ($filterhasil as $hu) {
							$datauji = $this->Model_hasiluji->getAllDataUjiById($hu->id_hasiluji);
							$datakategori = $this->Model_datadevice->getAllDataKategoriById($hu->id_device);?>
							<tr>
								<td align="center"><?=$no;?></td>
								<td align="center"><a href="" class="tampilModalTypeDevice"  data-toggle="modal" data-target="#modal-view" data-id_typedevice="<?=$hu->id_hasiluji?>"><i class="fa fa-folder-open"></i></a></td>
								<td><?=$hu->kode_device?></td>
								<td><?=$hu->nama_typedevice?></td>
								<td><?php foreach ($datakategori as $dk) {echo $dk->nama_kategori . '<br>';}?></td>
								<td><?= $hu->date_created; ?></td>
								<td><?php foreach ($datauji as $du) {echo $du->nama_datauji . '<br>';}?></td>
								<td><span class="badge badge-secondary"><?=$hu->nama_hasilpilih?> </span></td>
								<td align="center">
									<a href="<?=base_url();?>con_report/c_report/hapushasiluji/<?=$hu->id_hasiluji;?>" class = "btn  btn-danger btn-xs tombolHapus"><i class="fa fa-trash-o"></i>Delete</a>
								</td>

							</tr>

							<?php $no++;}?>

						</tbody>
						<tfoot>
							<tr>
								<th>No</th>
								<th>View</th>
								<th>No SN</th>
								<th>Nama Device</th>
								<th>Kategori Device</th>
								<th>Tanggal Uji</th>
								<th>Data Yang Di Uji</th>
								<th>Hasil Uji</th>
								<th>Action</th>
							</tr>
						</tfoot>
					</table>
					<tr>

					</div>
					<!-- /.box-footer-->
				</div>
				<!-- /.box -->

			</section>
			<!-- /.content -->
		</div>
		<!-- /.content-wrapper -->

		<div class="modal fade" id="modal-view">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span></button>
							<h4 class="modal-title">DETAIL REPORT DATA</h4>
						</div>
						<div class="modal-body">
							<form action="" method="post" >
								<div class="row">
									<div class="col-md-12">
										<div class="table-responsive">
											<p><i>Detail Report Data :</i></p>
											<table class="table table-striped table-bordered">
												<tbody>
													<tr>
														<th>Kode Device</th>
														<td><?=$hu->kode_device?></td>
													</tr>
													<tr>
														<th>Nama Device</th>
														<td><?=$hu->nama_typedevice?></td>
													</tr>
													<tr>
														<th>Kategori Device</th>
														<td><?php foreach ($datakategori as $dk) {echo $dk->nama_kategori . '<br>';}?></td>
													</tr>
												</tr>
												<tr>
													<th>Data Yang Diuji</th>
													<td><?php foreach ($datauji as $du) {echo $du->nama_datauji . '<br>';}?></td>
												</tr>
												<tr>
													<th>Tanggal Uji</th>
													<td><?= $hu->date_created; ?></td>
												</tr> 
												<tr>
													<th>Hasil Uji</th>
													<td><span class="badge badge-secondary"><?=$hu->nama_hasilpilih?></span></td>
												</tr>
												<tr>
													<th>Keterangan</th>
													<td><?=$hu->keterangan?></td>
												</tr>
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default pull-right" data-dismiss="modal">Close</button>
						</form>
					</div>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal-dialog -->
		</div>

