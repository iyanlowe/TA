
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Profil Admin 
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="#">Konfigurasi Website</a></li>
      <li class="active">Profil Admin</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="box">
      <div class="box-body">
       <form action="<?=base_url('admin/editadmin');?>">
         <!-- Default box -->
         <div class="container">
          <div class="card mb-5" style="max-width: 950px;">
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th width="20%">Company Name</th>
                  <th>: PT.NET 2 Software Jakarta Pusat</th>
                </tr>
                <tr>
                  <th width="20%">Administrator</th>
                  <th>: <?= $user['name'];?> </th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Email</td>
                  <td>: <?=$user['email'];?></td>
                </tr>
                <tr>
                  <td>Full name</td>
                  <td>: <?=$user['name']?></td>
                </tr>
                  <tr>
                  <td>Picture</td>
                  <td>: <img src="<?= base_url('assets/admin/dist/img/') . $user['image'];?>" class="img-thumbnail"></td>
                </tr>

              </tbody>
            </table>

          </div> 

          <div class="form-group">
            <label  class="col-md-2 control-label"></label>
            <div class="col-md-5">
              <button class="bnt btn-warning pull-left" name="edit" type="submit">
                <i class="fa fa-save"></i>Edit Profil
              </button>
            </div>
          </div>

        </form>


      </div>
    </div>
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
