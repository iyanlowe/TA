
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Admin Dashboard 
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Dashboard</a></li>
        <li class="active">Admin Dashboard </li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">

      <div class="col-lg-4 col-xs-4">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3>0<?php echo $total_device ?><sup style="font-size: 20px"></sup></h3>

              <p>Device Data</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <a href="<?php echo base_url('data/typedevice') ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

        <div class="col-lg-4 col-xs-4">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3>0<?php echo $total_users ?></h3>

              <p>Users Data</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a href="<?= base_url('data/managdata/datausers');?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

        <!-- ./col -->
        <div class="col-lg-4 col-xs-4">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3>0<?php echo $total_uji ?></h3>

              <p>Device Test Data</p>
            </div>
            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
            <a href="<?php echo base_url('data/managdata/datauji') ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
  </div>
      <!-- Default box -->
      <div class="box">
        <div class="container">
          <br>
        <div class="card mb-3" style="max-width: 540px;">
  <div class="row no-gutters">
    <div class="col-md-4">
      <img src="<?= base_url('assets/admin/dist/img/').$user['image']; ?>" class="img-thumbnail" >
    </div>
    <div class="col-md-7">
      <div class="card-body">
        <h1 class="card-title"><?= $user['name'];?></h1>
        <p class="card-text"><?= $user['email'];?></p>
        <p class="card-text"><small class="text-muted">Admin since <?= date('d F Y', $user['date_created']); ?> </small></p>
      </div>
    </div>
  </div>
</div>
        <!-- /.box-footer-->
      </div>
      <br>
      <!-- /.box -->

    </section>
    
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
