 <div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Edit Profile
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="#">Examples</a></li>
      <li class="active">Edit Profile</li>
    </ol>
  </section>

  <!-- Main content -->

  <section class="content">
    <div class="box">
      <div class="box-body">
        <div class="container">
             <?= $this->session->flashdata('message'); ?>
       <?= form_open_multipart('admin/editadmin');?>
       <!-- Default box -->
       <div class="form-group row">
        <label class="col-sm-2 col-form-label">Email</label>
        <div class="col-sm-7">
          <input type="text" name="email" id="email" class="form-control" value="<?=$user['email'];?>" readonly>
        </div>
      </div>
         <div class="form-group row">
        <label class="col-sm-2 col-form-label">Password</label>
        <div class="col-sm-7">
          <input type="password" name="password" id="password" class="form-control" value="<?=$user['password'];?>" readonly>
        </div>
      </div>

      <div class="form-group row">
        <label class="col-sm-2 col-form-label">Full name</label>
        <div class="col-sm-7">
          <input type="text" name="name" id="name" class="form-control" value="<?=$user['name']?>">
          <?= form_error('name','<small class="text-danger pl-3">', '</small>');?>
        </div>
      </div> 
      <div class="form-group row">
        <div class="col-sm-2 col-form-label">Picture</div> 
        <div class="col-sm-10">
          <div class="row">
            <div class="col-sm-3">
              <img src="<?= base_url('assets/admin/dist/img/') . $user['image'];?>" class="img-thumbnail">
            </div>
            <div class="col-sm-5">
              <div class="custom-file">
                <input type="file" name ="image" class="form-control"  placeholder="Upload Icon Baru" 
                value="">
              </div>
            </div>
          </div>
        </div>          

      </div> 

      <div class="form-group">
        <label  class="col-md-2 control-label"></label>
        <div class="col-md-5">
          <button class="bnt btn-success btn-lg pull-left" name="edit" type="submit">
            <i class="fa fa-save"></i>Edit Data
          </button>
        </div>
      </div>

    </form>


  </div>
</div>
</section>

<!-- /.content -->
</div>
<!-- /.content-wrapper -->
